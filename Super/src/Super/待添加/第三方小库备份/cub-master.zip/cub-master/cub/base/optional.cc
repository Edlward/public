#include "cub/base/optional.h"

namespace cub {

extern const NilOptional nilopt{{}};
}
