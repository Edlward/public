#include "cub/dci/interp/roles_undef.h"

#define __HAS_ROLE(p_role) HAS_ROLE(p_role)
