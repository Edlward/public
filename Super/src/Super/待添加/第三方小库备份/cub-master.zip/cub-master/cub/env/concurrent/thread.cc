#include "cub/env/concurrent/thread.h"

namespace cub {

Thread::~Thread() = default;
}
