#ifdef __HAS_ROLE
#undef __HAS_ROLE
#endif