#include "cub/base/inplace.h"

namespace cub {

extern const inplace_t inplace{};
}
