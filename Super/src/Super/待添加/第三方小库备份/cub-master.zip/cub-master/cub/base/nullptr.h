#ifndef EDC555D2_7134_1399_AD38_867CFE1D4564
#define EDC555D2_7134_1399_AD38_867CFE1D4564

namespace cub {

template <typename T>
constexpr T* nullptr_v = nullptr;

// template <typename T>
// constexpr T* nullptr_v() noexcept {
//   return nullptr;
// }

} // namespace cub

#endif
