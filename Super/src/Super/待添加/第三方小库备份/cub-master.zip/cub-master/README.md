# CUB(C++ Unified Base) 

CUB(C++ Unified Base) is an open-source collection of modern c++ library. 

## Test 

```bash
$ bazel test //cub/...
```

## Format

```bash
$ tools/clang-format.sh
```

## TODO

- support cmake build.
- doc.

