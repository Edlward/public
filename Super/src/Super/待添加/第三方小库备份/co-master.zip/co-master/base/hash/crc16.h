#pragma once

#include "../def.h"
#include <stddef.h>

uint16 crc16(const void* s, size_t n, uint16 crc);
