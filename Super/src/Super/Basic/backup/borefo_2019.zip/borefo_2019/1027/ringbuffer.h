﻿#ifndef RINGBUFFER_H_
#define RINGBUFFER_H_
//#include "ringbuffer.h"   //环形缓冲区队列
#include "global.h" 
#include <iostream>
#include "ThreadSync.h"

//同时包含cpp实现文件才能例化模板(且cpp的函数必须内联),否则所有类必须在.h文件实现
#ifndef ThreadSync_cpp
#define ThreadSync_cpp
#include "ThreadSync.cpp"   
#endif


//ringbuffer类模板 20150812 王领 原版本见历史备份
//refactor  by lizulin 李祖林 2017重构

//重构改封装跨平台的信号量，互斥锁等
//重构增加跨平台支持，增加考虑多个生产者/多消费者的情况


//注意理解使用:by lizulin 20180907
//实现生产者消费者模型不同线程生产/消费,除了用信号量控制货物个数外，
//还需要考虑不同线程同时生产(push);消费(get)问题
//关于互斥锁的使用,如果只有一个生产者线程，一个消费者线程，则不需要互斥锁
//如果有多个生产者则需要在推送函数内部用互斥锁保护WriteIndex
//如果有多个消费者者则需要在获取函数内部用互斥锁保护ReadIndex

//使用方法:
//一般只有一个生产者一个消费者的情况，如串联模式那么一个前一级push，后级get即可 
//可能有多个生产者的情况，每个生产者必须有用pushByMultipy推送数据。
//可能有多个消费者的情况，每个消费者必须用getByMultipy获取数据。
//对于消息队列，一般可能存在多个线程同时push给一个线程，用pushByMultipy
//消息队列内部线程一般只在其内部处理消息循环，用get即可


#include <condition_variable>
#include <mutex>
//C++11以上版本用std::mutex 和std::condition_variable (条件变量) 实现信号量

//逻辑已经实现正确在VS2012下不稳定，待续。20181016
class MySemaphoreC11 
{
public:
    MySemaphoreC11(unsigned int initCount = 1,unsigned int maxCount=1,const char* Name ="")
     :count(0),wakeups(0)
    {
        this->initCount=initCount;     
        count=initCount;
        wakeups=count;   //
        this->MaxCount=maxCount;
    }

#if 1
      //无限等待版本
      //void Wait()
      //{
      //        std::unique_lock<std::mutex> lock(mutex);
      //        while(count<=0) 
      //        {
      //            condition.wait(lock); //suspend and wait ...
      //        }
      //        --count;
      //        return;
      //}

    bool Signal()   //释放一个
    {
        std::unique_lock<std::mutex> lock(mutex);
        if (count<MaxCount)
        {
            ++count;
            ++wakeups;
            condition.notify_one();
            return true;
        }
        return false;
    }

        /**
         * 相当于信号量机制里面的P操作.
         * _count大于0(有资源)时,函数会立即返回,否则会阻塞调用此函数的线程.
         * 但如果等待时间超过seconds指定的值，会唤醒所有阻塞线程.
         * @param ms 等待时间(ms)
         */
       //等待一个
        bool Wait(unsigned int Waitms=0xFFFFFFFF)  //unsigned int 最多53天  阻塞等待
        {
            std::unique_lock<std::mutex> lock(mutex);
            if (count<=0) 
            { 
                //count>0 // [this]()->bool { return count>0; }
                auto status=condition.wait_for(lock,std::chrono::milliseconds(Waitms),
                    [&]()->bool { return wakeups>0; }); 
                if (!status)//status == std::cv_status::timeout) 
                {
                    return false;
                }
            }
            --count;
            --wakeups;
            return true;
        }
        //如果有阻塞的线程,则随机唤醒一个线程，相当于信号量机制里面的V操作.否则 立即返回.
        bool Signal(unsigned int lReleaseCount)     //返回值没有意义，为了与接口与win版一致暂留  释放多个
        {
            std::unique_lock<std::mutex> lock(mutex);
            for (unsigned int n=0;n<lReleaseCount;n++)   //释放多个
            {
                if (count<MaxCount)
                {
                    ++count;
                    ++wakeups;
                    condition.notify_one();    //有崩溃bug 待修复
                }
                else
                {
                    return false; //return true;
                }
            }
            return true;
        }

        //仿照Qt实现等待N个--待测试
        bool Wait(unsigned int N,unsigned int Waitms)  //
        {
            std::unique_lock<std::mutex> lock(mutex);
            if (count<N) 
            { 
                //count>0 // [this]()->bool { return count>0; }
                auto status=condition.wait_for(lock,std::chrono::milliseconds(Waitms),
                    [&]()->bool { return wakeups>=N; }); 
                if (!status)//status == std::cv_status::timeout) 
                {
                    return false;
                }
            }
            count-=N;
            wakeups-=N;
            return true;
        }

        //唤醒所有，作为信号量好像用不着
        void signalAll() 
        {
              Signal(MaxCount);
        }
#endif

#if 0
    ////带超时版本 by lizulin
    bool Wait(unsigned long long  TimesWait=0xFFFFFFFFFFFFFFFF)  //unsigned int 最多53天
    {
        std::unique_lock<std::mutex> lock(mutex);
        if (--count<0) 
        { 
            //最后参数pred表示 wait_until 的预测条件，只有当 pred 条件为 false时调用 wait()才会阻塞当前线程
            //wait_for指定时间段 wait_until指定一个绝对时刻
            //Predicate_con preCon(wakeups);  //addy by lizulin 不使用lambuda
            //if (!condition.wait_for(lock,std::chrono::milliseconds(TimesWait),preCon))
            if (!condition.wait_for(lock,std::chrono::milliseconds(TimesWait),[&]()->bool{ return wakeups>0;}))   //lambuda
            {
                //++count;// 失败复位？ by lizulin
                count=0;
                return false;
            }
            --wakeups;
            return true;
        }
       return true;
    }
    bool Signal(unsigned int lReleaseCount=1)
    {
         for (unsigned int n=0;n<lReleaseCount;n++)
         {
             std::lock_guard<std::mutex> lock(mutex);
             if(++count<=0) 
             { // have some thread suspended ?
                 ++wakeups;
                 condition.notify_one(); // notify one !
             }
         }
         return true;
    }
#endif

    //定义相同功能的接口Acquire  Release更加直观
    bool Acquire(unsigned int TimesWait)
    {
        return Wait(TimesWait);
    }
    bool Release(unsigned int lReleaseCount=1)
    {
        return Signal(lReleaseCount);
    }
    void ReInit()   //重新初始化，为了在ringbufer中使用是切换状态的时候复位到原来的信号量，一般情况不需要
    {
        Close();     //关闭之后重新打开
        Create();
    }
    void Close()
    {

    }
    void Create()
    {
    }
    void ReSet()  //复位信号量为初始值
    { 
        bool ret=true;
        int i;
        //while(ret)
        for(i=0;i<MaxCount;i++)
        {
            ret=Wait(1);   //使用完所有资源 Wait(0)也可以
            if (ret==false)
            {
                break;
            }
        }
        for(i=0;i<initCount;i++)
        {
            Signal();     //恢复初始资源
        }
    }
private:
    unsigned int initCount;      //记住构造时候的传参值，在重新初始化的时候使用
    unsigned int MaxCount;
    char m_name[128];
    int count;
    int wakeups;  //与count功能一样，用此变量辅助会更快，具体见 c++11中信号量(semaphore)的实现--待测试确认
    std::mutex mutex;
    std::condition_variable condition;
};





template <class T>
class ringbuffer
{
private:
    T *pData;                                          // 存放数据的指针
    unsigned int BufferSize;                    // 缓冲区大小
    unsigned int WriteIndex;                   // 当前写入位置
    unsigned int ReadIndex;                   // 当前读取位置
    int Count;                                         // A count for judge buffer empty or not
    MySemaphore semBufferEmpty;
    MySemaphore semBufferFull;

    //MySemaphoreC11 semBufferEmpty;
    //MySemaphoreC11 semBufferFull;

    //原设计错误，读写过程不能共用一个互斥锁，否则用信号量就没有意义了。
    MyMutex writeMutex;
    MyMutex readMutex;

    std::mutex mtx;
    std::condition_variable cv;
    //MyProcessMutex ProcessMutex;    //跨进程使用进程间互斥锁，当本类作为跨进程使用时候
public:
    ringbuffer(const unsigned int bufferSize = 8);
    ~ringbuffer();

    // 往缓冲区读写数据,否则当flag为true，则无限等待，false则默认时间等待
    bool push(const T& cargo, bool flag);
    bool get(T& cargo,bool flag);  //T get();  //原设计用返回NULL表明取数据失败不科学，如果是整数缓冲区null为0是有意义的

    //往缓冲区读写数据 以timeout作为延时,time=0XFFFFFFFF则无限等待
	bool push(const T& cargo,unsigned int timeout=Wait_Dafault);      //不能设定默认参数，否则调用不明确
	bool get(T& cargo,unsigned int timeout=Wait_Dafault);     

    //多生产者或多消费者版本
    bool pushByMultiple(const T& cargo, bool flag);
    bool getByMultiple(T& cargo,bool flag);
    bool pushByMultiple(const T& cargo,unsigned int timeout=Wait_Dafault);
    bool getByMultiple(T& cargo,unsigned int timeout=Wait_Dafault);     

    //仅查询，不影响内部计数器，既不push也不get,查询队列头/尾内容
    bool CheckHead(T& cargo);
    bool CheckTail(T& cargo);


    unsigned int getTotalSize() const {return BufferSize;}        // 返回总缓冲区大小，初始化时候决定
    unsigned int getWritePos() const {return WriteIndex;}      // 获取写入位置
    unsigned int getReadPos() const {return ReadIndex;}       // 获取读取位置
    bool IsFull()  const                                                           // 改缓冲区是否满标记 lizulin
    {
        if(Count >=BufferSize){ return true; }
        return false;
    }
    unsigned int getSize() const {return Count;}                               // 返回缓冲区货物剩余个数 等于写入个数减去读取个数
    bool clear(bool flag = true);                        // 清空缓冲区--flag为true表明存放的是new出来的指针,需要释放

    //回收ringbufer里面保存的内容，如果是new出来的指针，让外部可以有机会释放，否则不处理返回再即可
    //std::vector<T> clear()
    //{
    //    std::vector<T> VT;
    //    while (1)
    //    {
    //        T tmp;
    //        if (!get(tmp,0))   //立即获取，不等待，失败说明队列为空，退出
    //        {
    //            break;
    //        }
    //        VT.push_back(tmp);
    //    }
    //    return VT;
    //}
private:
	//实际直接存取数据 私有
	void pushData(const T& cargo);
	void getData(T& cargo);
};





template <class T>
ringbuffer<T>::ringbuffer(const unsigned int bufferSize):
    semBufferEmpty(bufferSize,bufferSize)
    ,semBufferFull(0,bufferSize)
{
    BufferSize = bufferSize;
    WriteIndex = 0;
    ReadIndex = 0;
    Count = 0;
    pData = new T[BufferSize];
/*
    for(int i = 0; i < BufferSize; i++)
    {
        pData[i] = NULL;
    }
*/
    char* pBegin=(char*)pData;
    for(unsigned int i = 0; i < BufferSize*sizeof(T); i++)  //memset without function
    {
        pBegin[i]=0;
    }
}

template <class T>
ringbuffer<T>::~ringbuffer()
{
    //for(unsigned int i = 0; i < BufferSize; i++)
    //{
    //    //if(data[i] != NULL)
    //        //delete data[i];
    //}
    delete[] pData;
}



template <class T>
void ringbuffer<T>::pushData(const T& cargo)
{
	pData[WriteIndex] = cargo;
	WriteIndex=getNextCycleIndex(WriteIndex,BufferSize);
	Count++;
}

template <class T>
void ringbuffer<T>::getData(T& cargo)
{
	cargo = pData[ReadIndex];
	ReadIndex=getNextCycleIndex(ReadIndex,BufferSize);
	Count--;
}


template <class T>
bool ringbuffer<T>::push(const T& cargo, bool flag)  // 往缓冲区放数据
{
    //
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;  //三目运算符与if else效率差异待确认
    //unsigned int timeout;
    //if(flag)
    //{
    //    timeout=Wait_INFINITE;
    //}
    //else
    //{
    //    timeout=Wait_Dafault;
    //}
    return push(cargo,timeout);
}

template <class T>
bool ringbuffer<T>::get(T& cargo,bool flag)  // 取出缓冲区数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return get(cargo,timeout);
}

template <class T>
bool ringbuffer<T>::push(const T& cargo,unsigned int timeout)
{
    if(!semBufferEmpty.Wait(timeout))
    {
        return false;
    }
    //writeMutex.Lock();

	pushData(cargo);

    //writeMutex.UnLock();
    semBufferFull.Signal();
    return true;
}

template <class T>
bool ringbuffer<T>::get(T& cargo,unsigned int timeout)
{
    if(!semBufferFull.Wait(timeout))
    {
        return false; 
    }
    //writeMutex.Lock();
    //readMutex.Lock();

	getData(cargo);

    //readMutex.UnLock();
    //writeMutex.UnLock();

    semBufferEmpty.Signal();
    return true;
}

template <class T>
bool ringbuffer<T>::pushByMultiple(const T& cargo, bool flag)  // 往缓冲区放数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return pushByMultiple(cargo,timeout);
}

template <class T>
bool ringbuffer<T>::getByMultiple(T& cargo,bool flag)  // 取出缓冲区数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return getByMultiple(cargo,timeout);
}

template <class T>
bool ringbuffer<T>::pushByMultiple(const T& cargo,unsigned int timeout)
{
    if(!semBufferEmpty.Wait(timeout))
    {
        return false;
    }
    writeMutex.Lock();
    pushData(cargo);
    writeMutex.UnLock();
    semBufferFull.Signal();
    return true;
}

template <class T>
bool ringbuffer<T>::getByMultiple(T& cargo,unsigned int timeout)
{
    if(!semBufferFull.Wait(timeout))
    {
        return false; 
    }
    readMutex.Lock();
    getData(cargo);
    readMutex.UnLock();
    semBufferEmpty.Signal();
    return true;
}
 

template <class T>
bool ringbuffer<T>::CheckHead(T& cargo)
{
    readMutex.Lock();
    if (Count<=0)    //有货物
    {
        readMutex.UnLock();
        return false;
    }

    //unsigned int RIndex=getPrevCycleIndex(WriteIndex,BufferSize);  //取即将写的上一个
    //cargo = pData[RIndex];   //队列头部

	cargo = pData[ReadIndex];

    readMutex.UnLock();
    return true;
}

template <class T>
bool ringbuffer<T>::CheckTail(T& cargo)
{
    readMutex.Lock();
    if (Count<=0)
    {
        return false;
    }

    //unsigned int RIndex=getPrevCycleIndex(ReadIndex,BufferSize);   //取即将读的上一个
    //cargo = pData[RIndex];  //队列尾部，准备写入位置

	cargo = pData[ReadIndex];

    readMutex.UnLock();
    return true;
}


template <class T>
bool ringbuffer<T>::clear(bool flag = true)  // 清空缓冲区
{
    //可能设计不合理，待续
#if 1
    writeMutex.Lock();
    readMutex.Lock();

    semBufferEmpty.ReSet();
    semBufferFull.ReSet();
    //读写位置复位
    WriteIndex = 0;
    ReadIndex = 0;
    Count = 0;

    readMutex.UnLock();
    writeMutex.UnLock();
#endif
    return true;
}



#endif // RINGBUFFER_H_
