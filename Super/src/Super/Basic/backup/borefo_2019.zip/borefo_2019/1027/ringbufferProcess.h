﻿#ifndef RINGBUFFERPROCESS_H_
#define RINGBUFFERPROCESS_H_
//#include "ringbufferProcess.h"   //跨进程环形缓冲区

#include "global.h" 

//refactoring  by lizulin 李祖林 重构
//重构改封装跨平台的信号量，互斥量 
#include <iostream>
#include <string>
#include "ThreadSync.h"


//同时包含cpp实现文件才能例化模板(且cpp的函数必须内联),否则所有类必须在.h文件实现
#ifndef ThreadSync_cpp
#define ThreadSync_cpp
#include "ThreadSync.cpp"   
#endif

#include "ShareMemory.h"

#ifndef ShareMemory_cpp
#define ShareMemory_cpp
#include "ShareMemory.cpp"  
#endif

//改通过命名信号量，实现跨进程的ringbufer，一个进程里面push，另一个进程里面get，
//通过共享内存实现数据交互
template <class T>
class ringbufferProcess
{
private:
    T *pData;                                              // 存放数据的指针
    unsigned int BufferSize;                        // 缓冲区大小
    //读写可能在不同线程，需要把一些计数器变量在进程间共享，考虑避免多次初始化问题
    struct ShareCount
    {
        int initKey;                                                         //创建者标记，决定是否初始化以下变量
        unsigned int BufferSize;                                    // 缓冲区大小
        unsigned int WriteIndex;                                   // 当前写入位置
        unsigned int ReadIndex;                                   // 当前读取位置
        int Count;									                        //记录有效货物数量 A count for judge buffer empty or not
    };
    ShareCount* pSC;
    ShareMemoryByMap m_ShareMem;
    MySemaphore semBufferEmpty;
    MySemaphore semBufferFull;
    //跨进程使用进程间互斥锁，当本类作为跨进程使用时候
    MyProcessMutex writeMutex;
    MyProcessMutex readMutex;
public:
    inline ringbufferProcess(const unsigned int bufferSize = 8,const char* name=NULL);
    inline ~ringbufferProcess();
    // 往缓冲区写数据,flag为true，则无限等待，false则有限时间内没有空位则丢弃数据
    inline bool push(const T& cargo, bool flag);           //为了效率用引用
    inline bool get(T& cargo,bool flag);           

    //T get(bool flag = true); //原设计，返回NULL不科学，如果是整数缓冲区null为0是有意义的

    //往缓冲区读写数据 以timeout作为延时,time=0XFFFFFFFF则无限等待
	inline bool push(const T& cargo,unsigned int timeout=Wait_Dafault);      //不能设定默认参数，否则调用不明确
	inline bool get(T& cargo,unsigned int timeout=Wait_Dafault);     

    //多生产者或多消费者版本
    bool pushByMultiple(const T& cargo, bool flag);
    bool getByMultiple(T& cargo,bool flag);
    bool pushByMultiple(const T& cargo,unsigned int timeout=Wait_Dafault);
    bool getByMultiple(T& cargo,unsigned int timeout=Wait_Dafault);     

/*
    //跨进程传递共享内存指针使用,推送指针前转成相对地址在推送,取到指针后再映射成本进程指针可以直接使用--只能在跨进程中传递同名共享内存指针
    inline bool PushShareMemPoint(const T cargo, bool flag = true); // 往缓冲区写数据,flag为true，则无限等待，false则有限时间内没有空位则丢弃数据
    inline bool GetShareMemPoint(T& cargo,bool flag = true);          // 取出缓冲区数据,flag为true，则无限等待，false则有限时间内没取到数据返回空
    void* pShareMem;     //共享内存在本进程映射地址
    inline void setShareMemPoint(void* p);
*/
    inline unsigned int getTotalSize() const {return pSC->BufferSize;}     // 返回总缓冲区大小，初始化时候决定
    inline unsigned int getWritePos() const {return pSC->WriteIndex;}    // 获取写入位置
    inline unsigned int getReadPos() const {return pSC->ReadIndex;}     // 获取读取位置
    inline bool IsFull() const 
    {
        if(pSC->Count >=BufferSize){return true;}
        return false;
    }
    unsigned int getSize() const {return pSC->Count;}     // 返回缓冲区货物剩余个数 等于写入个数减去读取个数
    inline bool clear(bool flag = true);                  // 清空缓冲区--flag为true表明存放的是new出来的指针,需要释放

private:
    //实际直接存取数据 私有
    void pushData(const T& cargo);
    void getData(T& cargo);
};

template <class T>
ringbufferProcess<T>::ringbufferProcess(const unsigned int bufferSize,const char* name=""): 
    semBufferEmpty(bufferSize,bufferSize,std::string(std::string(name)+"_semEmpty").c_str())
    ,semBufferFull(0,bufferSize,std::string(std::string(name)+"_semFull").c_str())
    ,writeMutex(std::string(std::string(name)+"_writeMutex").c_str())
    ,readMutex(std::string(std::string(name)+"_readMutex").c_str())
    ,m_ShareMem(bufferSize*sizeof(T)+sizeof(ShareCount),std::string(std::string(name)+"_privateMem").c_str())
{
    BufferSize = bufferSize;

    //pData = new T[BufferSize];
    //用共享内存构造对象
    void* pShare=m_ShareMem.getAddress();
    //pData=operator new(pShare) T[BufferSize];
    pData=(T*)pShare;
    //进程间共享计数器的初始化
    pSC=(ShareCount*)((char*)pShare+bufferSize*sizeof(T));
    if (pSC->initKey!=0X08250512)
    {
        pSC->WriteIndex=0;                                   // 当前写入位置
        pSC->ReadIndex=0;                                   // 当前读取位置
		pSC->BufferSize=BufferSize;
        pSC->Count=0;	
        pSC->initKey=0X08250512;
    }
}

template <class T>
ringbufferProcess<T>::~ringbufferProcess()  
{
    //for(int i = 0; i < BufferSize; i++)  // 若放的不是指针，这句话删去
    //{
    //	//if(data[i] != NULL)
    //	//delete data[i];
    //}
    //delete[]  pData;

    //共享内存不需要释放，只需要构造析构函数即可--一般也不需要，因为在只能在进程中传递基础类型，不能传递std::string之类的结构
    for(int i = 0; i < BufferSize; i++)  // 若放的不是指针，这句话删去
    {
          pData[i].~T();    //如何显示调用模板类型的析构函数
    }
}

template <class T>
void ringbufferProcess<T>::pushData(const T& cargo)
{
	pData[pSC->WriteIndex] = cargo;
	pSC->WriteIndex=getNextCycleIndex(pSC->WriteIndex,BufferSize);      //pSC->或BufferSize
	pSC->Count++;
}

template <class T>
void ringbufferProcess<T>::getData(T& cargo)
{
    cargo = pData[pSC->ReadIndex];
    pSC->ReadIndex=getNextCycleIndex(pSC->ReadIndex,BufferSize);  //pSC->或BufferSize
    pSC->Count--;
}




template <class T>
bool ringbufferProcess<T>::push(const T& cargo, bool flag)  // 往缓冲区放数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return push(cargo,timeout);
}

template <class T>
bool ringbufferProcess<T>::get(T& cargo,bool flag)  // 取出缓冲区数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return get(cargo,timeout);
}


template <class T>
bool ringbufferProcess<T>::push(const T& cargo,unsigned int timeout)
{
    if(!semBufferEmpty.Wait(timeout))
    {
        return false;
    }
    //writeMutex.Lock();
    pushData(cargo);
    //writeMutex.UnLock();
    semBufferFull.Signal();
    return true;
}

template <class T>
bool ringbufferProcess<T>::get(T& cargo,unsigned int timeout)
{
    if(!semBufferFull.Wait(timeout))
    {
        //return NULL;  //不科学
        return false;
    }

    //readMutex.Lock();
    getData(cargo);
    //readMutex.UnLock();
    semBufferEmpty.Signal();
    return true;
}



template <class T>
bool ringbufferProcess<T>::pushByMultiple(const T& cargo, bool flag)  // 往缓冲区放数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return pushByMultiple(cargo,timeout);
}

template <class T>
bool ringbufferProcess<T>::getByMultiple(T& cargo,bool flag)  // 取出缓冲区数据
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return getByMultiple(cargo,timeout);
}

template <class T>
bool ringbufferProcess<T>::pushByMultiple(const T& cargo,unsigned int timeout)
{
    if(!semBufferEmpty.Wait(timeout))
    {
        return false;
    }
    writeMutex.Lock();
    pushData(cargo);
    writeMutex.UnLock();
    semBufferFull.Signal();
    return true;
}

template <class T>
bool ringbufferProcess<T>::getByMultiple(T& cargo,unsigned int timeout)
{
    if(!semBufferFull.Wait(timeout))
    {
        return false; 
    }
    readMutex.Lock();
    getData(cargo);
    readMutex.UnLock();
    semBufferEmpty.Signal();
    return true;
}


template <class T>
bool ringbufferProcess<T>::clear(bool flag = true)  // 清空缓冲区
{
    //可能设计不合理，待续
#if 1
    writeMutex.Lock();
    readMutex.Lock();

    semBufferEmpty.ReSet();
    semBufferFull.ReSet();
    //读写位置复位
    pSC->WriteIndex = 0;
    pSC->ReadIndex = 0;
    pSC->Count = 0;

    readMutex.UnLock();
    writeMutex.UnLock();
#endif
    return true;
}



//显示实例化
//template class ringbufferProcess<int>;
//template class ringbufferProcess<cardInput*>;


//template<class T> class B { ..... }; // 普通版本
//template<class T>class B<T*> { ..... }; //这个偏特化版本只接收指针类型的模板实参 
//template<class T>class B<T&> { ..... }; // 这个偏特化版本只接受引用类型的模板实参


//对指针使用共享内存方式的特化  T只能是
template <class T>
class ringbufferProcessWrap
{
public:
    ringbufferProcessWrap(const unsigned int bufferSize = 8,const char* name=""):
        ProcessShareRingbuffer(bufferSize,std::string(std::string(name)+"ringbuffer").c_str())
        ,ShareMemAudioBuf(sizeof(T)*bufferSize,std::string(std::string(name)+"shareMem").c_str())
    {
        pShareMemAddress=ShareMemAudioBuf.getAddress(); 
        IndexBuf=0;
        this->BufferSize=bufferSize;
    }
    ~ringbufferProcessWrap()
    {

    }
    T* getNextBufferFromShareMem()
    {
        IndexBuf=getNextCycleIndex(IndexBuf,this->BufferSize);
        return pShareMemAddress+IndexBuf*sizeof(T);
    }
    inline bool push(const T*& cargo, bool flag)
    {
            unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
            push(cargo,timeout);
    }
    inline bool get(T*& cargo,bool flag)
    {
            unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
            get(cargo,timeout);
    }
   inline bool push(const T*& cargo,unsigned int timeout=Wait_Dafault)
   {
       T*  inPush=(T*)((char*)cargo-(char*)pShareMemAddress);
       return ProcessShareRingbuffer.push(cargo,timeout);
   }
   inline bool get(T*& cargo,unsigned int timeout=Wait_Dafault)
   {
        bool ret=ProcessShareRingbuffer.get(cargo,timeout);
        T* out=(T*)((char*)cargo+(unsigned long long)(pShareMemAddress)); 
        cargo=out;
        return ret;
   }
private:
    ringbufferProcess<T*> ProcessShareRingbuffer;
    ShareMemoryByMap ShareMemAudioBuf;
    void* pShareMemAddress;
    unsigned int BufferSize;
    unsigned int IndexBuf;
};




#endif // RINGBUFFER_H_
