#include "ringbufferSimple.h"

#include <iostream>

#include "ThreadSync.h"

//ֻҪĳ���౻����ģ�����棬�κ�ʹ�õĵط�������������ʽҲ����cpp�ļ����������ӳ�������ʱ��� 
#ifndef ThreadSync_cpp
#define ThreadSync_cpp
#include "ThreadSync.cpp"   
#endif

class ringbufferSimple::Impl
{
public:
    Impl(const unsigned int bufferSize = 8):
        semBufferEmpty(bufferSize,bufferSize)
        ,semBufferFull(0,bufferSize)
    {
    }
    ~Impl(){};
    MySemaphore semBufferEmpty;
    MySemaphore semBufferFull;
    MyMutex writeMutex;
    MyMutex readMutex;
};


ringbufferSimple::ringbufferSimple(const unsigned int DataSize,const unsigned int bufferSize) :
    DataSize(DataSize)
{
    pImpl=new Impl(bufferSize);
    BufferSize = bufferSize;
    WriteIndex = 0;
    ReadIndex = 0;
    Count = 0;
    pData = new char[BufferSize*DataSize];

    char* pBegin=(char*)pData;
    for(unsigned int i = 0; i < BufferSize*DataSize; i++)  //sizeof()
    {
        pBegin[i]=0;   //memset 
    }
}

ringbufferSimple::~ringbufferSimple()
{
    //for(unsigned int i = 0; i < BufferSize; i++)  // ���ŵĲ���ָ�룬��仰ɾȥ
    //{
    //	//if(data[i] != NULL)
    //	//delete data[i];
    //}
    delete[] pData;
    delete pImpl;
}

void ringbufferSimple::pushData(const void* cargo)
{
    memcpy((void*)(pData+WriteIndex*DataSize),cargo,DataSize);
    WriteIndex=getNextCycleIndex(WriteIndex,BufferSize);
    Count++;
}

void ringbufferSimple::getData(void* cargo)
{
    memcpy(cargo,(void*)(pData+ReadIndex*DataSize),DataSize);
    ReadIndex=getNextCycleIndex(ReadIndex,BufferSize);
    Count--;
}

bool ringbufferSimple::push(const void* cargo, bool flag) // ��������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return push(cargo,timeout);
}

bool ringbufferSimple::push(const void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferEmpty.Wait(timeout)==false)
    {
        return false;
    }
    pImpl->writeMutex.Lock();
    pushData(cargo);
    pImpl->writeMutex.UnLock();
    pImpl->semBufferFull.Signal();
    return true;
}

bool ringbufferSimple::get(void* cargo,bool flag) // ȡ������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return get(cargo,timeout);
}

bool ringbufferSimple::get(void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferFull.Wait(timeout)==false)
    {
        return false; //return NULL;
    }
    //pImpl->readMutex.Lock();
    pImpl->writeMutex.Lock();
    getData(cargo);
    pImpl->writeMutex.UnLock();

    //pImpl->readMutex.UnLock();
    pImpl->semBufferEmpty.Signal();
    return true;
}


bool ringbufferSimple::pushByMultiple(const void* cargo, bool flag) // ��������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return pushByMultiple(cargo,timeout);
}

bool ringbufferSimple::pushByMultiple(const void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferEmpty.Wait(timeout)==false)
    {
        return false;
    }
    pImpl->writeMutex.Lock();
    pushData(cargo);
    pImpl->writeMutex.UnLock();
    pImpl->semBufferFull.Signal();
    return true;
}

bool ringbufferSimple::getByMultiple(void* cargo,bool flag) // ȡ������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return getByMultiple(cargo,timeout);
}

bool ringbufferSimple::getByMultiple(void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferFull.Wait(timeout)==false)
    {
        return false; //return NULL;
    }
    pImpl->readMutex.Lock();
    getData(cargo);
    pImpl->readMutex.UnLock();
    pImpl->semBufferEmpty.Signal();
    return true;
}


bool ringbufferSimple::clear(bool flag) // ��ջ�����
{
    pImpl->writeMutex.Lock();
    //pImpl->readMutex.Lock();

    pImpl->semBufferEmpty.ReSet();
    pImpl->semBufferFull.ReSet();

    //��дλ�ø�λ
    WriteIndex = 0;
    ReadIndex = 0;
    Count = 0;

    //pImpl->readMutex.UnLock();
    pImpl->writeMutex.UnLock();
    return true;
}




#include <string>

#include "ShareMemory.h"

//ֻҪĳ���౻����ģ�����棬�κ�ʹ�õĵط�������������ʽҲ����cpp�ļ����������ӳ�������ʱ��� 
#ifndef ShareMemory_cpp
#define ShareMemory_cpp
#include "ShareMemory.cpp"  
#endif

class ringbufferProcessSimple::Impl
{
public:
    Impl(unsigned int  DataSize,unsigned int bufferSize = 8,const char* name=""):
        semBufferEmpty(bufferSize,bufferSize,std::string(std::string(name)+"_semEmpty").c_str())
        ,semBufferFull(0,bufferSize,std::string(std::string(name)+"_semFull").c_str())
        ,writeMutex(std::string(std::string(name)+"_writeMutex").c_str())
        ,readMutex(std::string(std::string(name)+"_readMutex").c_str())
        ,m_ShareMem(bufferSize*DataSize+sizeof(ShareCount),std::string(std::string(name)+"_privateMem").c_str())
    {
    }
    ~Impl(){};
    MySemaphore semBufferEmpty;
    MySemaphore semBufferFull;
    MyProcessMutex writeMutex;
    MyProcessMutex readMutex;
    ShareMemoryByMap m_ShareMem;
};

ringbufferProcessSimple::ringbufferProcessSimple(unsigned int DataSize,unsigned int bufferSize,const char* name/*=NULL*/) : 
    BufferSize(bufferSize)
    ,DataSize(DataSize)
{
    pImpl=new Impl(DataSize,bufferSize,name);

    BufferSize = bufferSize;

    ////count = BufferSize;
    ////pData = new T[BufferSize];
    ////�ù����ڴ湹�����
    void* pShare=pImpl->m_ShareMem.getAddress();
    ////pData=operator new(pShare) T[BufferSize];
    //pData=(T*)pShare;

    pData=(char*)pShare;

    //���̼乲���������ĳ�ʼ��
    pSC=(ShareCount*)((char*)pShare+bufferSize*DataSize);  //sizeof(T)
    if (pSC->initKey!=0X08250512)
    {
        pSC->WriteIndex=0;                                   // ��ǰд��λ��
        pSC->ReadIndex=0;                                   // ��ǰ��ȡλ��
		pSC->BufferSize=BufferSize;
        pSC->Count=0;	
        pSC->initKey=0X08250512;
    }
}

ringbufferProcessSimple::~ringbufferProcessSimple() 
{
    for(unsigned int i = 0; i < BufferSize; i++)  // ���ŵĲ���ָ�룬��仰ɾȥ
    {
        //if(data[i] != NULL)
        //delete data[i];
    }

    //delete[]  pData;
    //�����ڴ治��Ҫ�ͷţ�ֻ��Ҫ����������������--һ��Ҳ����Ҫ����Ϊ��ֻ���ڽ����д��ݻ������ͣ����ܴ���std::string֮��Ľṹ
    //for(int i = 0; i < BufferSize; i++)  // ���ŵĲ���ָ�룬��仰ɾȥ
    //{
    //	pData[i].~T();    //�����ʾ����ģ�����͵���������
    //}

    delete pImpl;
}

void ringbufferProcessSimple::pushData(const void* cargo)
{
    memcpy((pData+pSC->WriteIndex*DataSize),cargo,DataSize);
    pSC->WriteIndex=getNextCycleIndex(pSC->WriteIndex,BufferSize);  //��pSC->BufferSize
    pSC->Count++;
}

void ringbufferProcessSimple::getData(void* cargo)
{
    memcpy(cargo,(pData+pSC->ReadIndex*DataSize),DataSize);
    pSC->ReadIndex=getNextCycleIndex(pSC->ReadIndex,BufferSize);  //��pSC->BufferSize
    pSC->Count--;	
}

bool ringbufferProcessSimple::push(const void* cargo, bool flag) // ��������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return push(cargo,timeout);
}

bool ringbufferProcessSimple::push(const void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferEmpty.Wait(timeout)==false)
    {
        return false;
    }
    //pImpl->writeMutex.Lock();
    pushData(cargo);
    //pImpl->writeMutex.UnLock();
    pImpl->semBufferFull.Signal();
    return true;
}

bool ringbufferProcessSimple::get(void* cargo,bool flag) // ȡ������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return get(cargo,timeout);
}

bool ringbufferProcessSimple::get(void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferFull.Wait(timeout)==false)
    {
        return false;
    }
    //pImpl->readMutex.Lock();
    getData(cargo);
    //pImpl->readMutex.UnLock();
    pImpl->semBufferEmpty.Signal();
    return true;
}

bool ringbufferProcessSimple::pushByMultiple(const void* cargo, bool flag) // ��������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return pushByMultiple(cargo,timeout);
}

bool ringbufferProcessSimple::pushByMultiple(const void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferEmpty.Wait(timeout)==false)
    {
        return false;
    }
    pImpl->writeMutex.Lock();
    pushData(cargo);
    pImpl->writeMutex.UnLock();

    pImpl->semBufferFull.Signal();
    return true;
}

bool ringbufferProcessSimple::getByMultiple(void* cargo,bool flag) // ȡ������������
{
    unsigned int timeout=(flag)?Wait_INFINITE:Wait_Dafault;
    return getByMultiple(cargo,timeout);
}

bool ringbufferProcessSimple::getByMultiple(void* cargo,unsigned int timeout)
{
    if(pImpl->semBufferFull.Wait(timeout)==false)
    {
        return false;
    }
    pImpl->readMutex.Lock();
    getData(cargo);
    pImpl->readMutex.UnLock();
    pImpl->semBufferEmpty.Signal();
    return true;
}



bool ringbufferProcessSimple::clear(bool flag /*= true*/) // ��ջ�����
{
    pImpl->writeMutex.Lock();
    //pImpl->readMutex.Lock();

    pImpl->semBufferEmpty.ReSet();
    pImpl->semBufferFull.ReSet();

    //��дλ�ø�λ
    pSC->WriteIndex = 0;
    pSC->ReadIndex = 0;
    pSC->Count=0;	

    //pImpl->readMutex.UnLock();
    pImpl->writeMutex.UnLock();

    return true;
}



int Test_ringbufferSimple()
{
        std::cout<<"Test_ringbufferSimple()"<<std::endl;
    {

        std::cout<<"Test_ringbufferSimple()"<<std::endl;

        ringbufferSimple ring(sizeof(double),1000);
        for (int i=0;i<50;i++)
        {
            double v=i;
            ring.push(&v,false);
            std::cout<<"put v= "<<v<<std::endl;
        }
        for (int i=0;i<50;i++)
        {
            double v;
            ring.get(&v,false);
            std::cout<<"get v= "<<v<<std::endl;
        }
    }


    {
        std::cout<<"ringbufferProcessSimple()"<<std::endl;

        ringbufferProcessSimple ring(sizeof(double),1000,"name");
        for (int i=0;i<50;i++)
        {
            double v=i;
            ring.push(&v,false);
            std::cout<<"put v= "<<v<<std::endl;
        }


        {   
            //����ʵ����ģ������
            ringbufferProcessSimple ring(sizeof(double),1000,"name");
            for (int i=0;i<50;i++)
            {
                double v;
                ring.get(&v,false);
                std::cout<<"get v= "<<v<<std::endl;
            }
        }

    }

    return 0;
}
