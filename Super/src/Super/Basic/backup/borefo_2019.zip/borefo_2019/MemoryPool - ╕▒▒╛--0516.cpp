#include "MemoryPool.h"


NAME_SPACE_MAIN_BEGIN




MemPoolByQueue::MemPoolByQueue(unsigned int MemPoolSize)
    :MemPoolSize(MemPoolSize)
{
    pMemBegin=(char*)::malloc(MemPoolSize);
    if (pMemBegin==NULL)
    {
        printf("Error at: MemPoolByQueue::MemPoolByQueue() malloc() size=%d\n",MemPoolSize);
        exit(-1);
    }
    pMemBlockSize=(unsigned int*)::malloc(MemPoolSize/512*sizeof(unsigned int));
    pMemEnd=(char*)((unsigned int)pMemBegin+MemPoolSize);
    pCurrent=0;
}

MemPoolByQueue::~MemPoolByQueue(void)
{
    free(pMemBegin);
}

void* MemPoolByQueue::malloc(unsigned int size)
{
    if (pCurrent+size>(unsigned int)(pMemEnd-pMemBegin))
    {
        pCurrent=0;
    }
    void* p=(void*)((unsigned int)pMemBegin+pCurrent);
    pCurrent+=size;
    return p;
}

void MemPoolByQueue::free(void* p)
{
    if (p<pMemBegin||p>pMemEnd)   //Ҫ�ͷŵ�ָ�벻�ڱ��ڴ�ط�Χ
    {
        return;
    }
    unsigned int BlockNum=((char*)p-pMemBegin)/512;
    unsigned int  pMemSize=pMemBlockSize[BlockNum];
    pFree+=pMemSize;
    pMemBlockSize[BlockNum]=0;
}




#ifdef UNIT_TEST
#include "SuperTime.h"

USING_NAME_SPACE_MAIN

int Test_MemoryPool()
{
    const size_t PoolMgrSize=100*1024;          //�ڴ�ع���������С
    MemPool memPool(PoolMgrSize);
    std::vector<void*> Vused;
    SuperTime tm("MemPool()");

    for (unsigned int K=0;K<10000;K++)
    {
            Vused.clear();
            unsigned sumMem=0;
            for (unsigned int n=0;n<10000;n++)
            {
                tm.getBeginTime();

                unsigned int mallocSize=rand()%(PoolMgrSize);

                //unsigned int randValue=rand();  //0-32767
                //unsigned int mallocSize=(randValue*100)%(PoolMgrSize);

                sumMem+=mallocSize;
                //printf("n:%u mallocSize:%u\n",n,mallocSize);

                void* pData=memPool.Malloc(mallocSize);
                //void* pData=malloc(mallocSize);   //��ϵͳ�����Ա� ��Լ��30��
                Vused.push_back(pData);

                memset(pData,53,mallocSize);

                //memPool.Free(pData);   //�����ظ��ͷ�

                tm.getEndPrint(100);
            }

            for (size_t n=0;n<Vused.size();n++)
            {
                void* p=Vused.at(n);
                memPool.Free(p);

                //::free(p);
            }
            //memPool.FreeSpace();
    }


     PRINT_FUN_END

    //printf("MemBlock ObjCnt:%d\n",MemBlock::ObjCnt);

    return 0;
}
#endif

NAME_SPACE_MAIN_END

