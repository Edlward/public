﻿#ifndef CHUNK_H_
#define CHUNK_H_

/*
按照素材标准文档编写的素材结构  2015-11-23 王领
用于将码流解析成素材
同时，为了检测与实验，代码中还包括了码流生成，在
实际使用时不会用到那部分代码。
*/

#include <iostream>
#include <vector>
#include "Int24.h"

using namespace std;

#ifdef _WIN32

#ifdef BASIC_EXPORTS
#define BASIC_API __declspec(dllexport)
#else
#define BASIC_API __declspec(dllimport)
#endif

#else
#define BASIC_API 
#endif

class BASIC_API dataStruct
{
public:
	unsigned char * _data;
	int length; // _data数组的长度
	int p;      // 数组下标
	int pBit;   // bit位下标
	unsigned int mask8;

	dataStruct();
	dataStruct(void *inputData, int len);
	~dataStruct();
	bool nextByte();                       // 上一字节的八个比特已经读取完，跳转到下一个字节
	int get_int(int num);                  // 取num位整型，要求num是16或24
	unsigned long long get_uint(int num);  // 取num位非负整型
	int get_bit();                         // 取一个比特
	int get_rle();                         // 取得一个rle数据
	unsigned long long get_var(int N);     // 取得一个var(N, 64)的数据
	float get_float();                     // 取得一个32位浮点型数据
};

class BASIC_API dataStructOut
{
public:
	unsigned char * _data;
	int length;   // _data数组的长度
	int p;        // 数组下标
	int pBit;     // bit位下标
	unsigned int mask1;



	dataStructOut(int len);
	~dataStructOut();
	bool nextByte();
	void write_int(int num, int bitNum); 
	void write_uint(unsigned long long num, int bitNum);
	void write_bit(int bit);
	void write_rle(int num);
	void write_var(unsigned long long num, int N);
	void write_float(float num);
};


/////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////

class BASIC_API groupChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long channelCount;
	vector<unsigned long long> channelId;
	unsigned long long objCount;
	vector<unsigned long long> objId;

	groupChunk();
	int read();

	void write();
	void print();
};

class BASIC_API channelData
{
public:
	unsigned long long channelId;
	unsigned long long routingDestination;
	unsigned long long waveformId;

	int read();

	void write();
	void print();
};

class BASIC_API useCaseData
{
public:
	int constraintCount;
	vector<int> constraints;
	unsigned long long tieBreaker;

	int read();

	void write();
	void print();
};

class BASIC_API sfgrsData
{
public:
	vector<float> gainCoefficient;
	
	void set_default(unsigned long long channelcount, unsigned long long routingdescount);
	int read(unsigned long long channelcount, unsigned long long routingdescount, const sfgrsData preSfgrs);

	void write(unsigned long long channelcount, unsigned long long routingdescount);
	void print(unsigned long long channelcount, unsigned long long routingdescount);
};

class BASIC_API ObjMetaData
{
public:
	int id;
	unsigned int timecode;   //改unsigned int
	float positionX;  // x
	float positionY;  // y
	float positionZ;  // z
	float extent;
	float gain;
	float coherence;
	float snap;
	float zoneGain[19];
	ObjMetaData();
};

class BASIC_API objSubframeData:public ObjMetaData
{
public:
	bool skipSubframe;
	bool skipPositionX;
	bool skipPositionY;
	bool skipPositionZ;
	bool skipExtent;
	bool skipGain;
	bool skipCoherence;
	bool skipSnap;
	bool skipAllZones;

	void set_default();
	int read(const objSubframeData preObjSub);

	void write();
	void print();
};

class BASIC_API objAltChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	useCaseData useCase;
	int isActive;
	int isAllocentric;
	unsigned long long waveformId;
	int subframeBlockSize;
	vector<objSubframeData> subframes;

	objAltChunk();
	int read(int frameblocksize);

	void write(int frameblocksize);
	void print(int frameblocksize);
};

class BASIC_API objDefChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	bool isActive;
	bool isAllocentric;
	unsigned long long waveformId;
	int subframeBlockSize;
	vector<objSubframeData> subframes;

	objDefChunk();
	int read(int frameblocksize);

	void write(int frameblocksize);
	void print(int frameblocksize);
};

class BASIC_API objectChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long objectId;
	objDefChunk objDef;
	vector<objAltChunk> objAlt;

	objectChunk();
	int read(int frameblocksize);

	void write(int frameblocksize);
	void print(int frameblocksize);
};

class BASIC_API sfgRemapChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	useCaseData useCase;
	unsigned long long routingDesCount;
	vector<unsigned long long> routingDestion;
	int subframeBlockSize;
	vector<sfgrsData> subframes;

    sfgRemapChunk();
	int read(int frameblocksize, unsigned long long channelcount);

	void write(int frameblocksize, unsigned long long channelcount);
	void print(unsigned long long channelcount);
};

class BASIC_API sfgAlternativeChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	useCaseData useCase;
	unsigned long long channelCount;
	vector<channelData> channels;

	sfgAlternativeChunk();
	int read(int frameblocksize);

	void write(int frameblocksize);
	void print();
};

class BASIC_API sfgDefinitionChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long channelCount;
	vector<channelData> channels;

	sfgDefinitionChunk();
	int read(int frameblocksize, unsigned long long &channelcount);

	void write(int frameblocksize, unsigned long long &channelcount);
	void print();
};

class BASIC_API sfGroupChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long sfGroupId;
	int isMainSound;
	sfgDefinitionChunk sgd;
	vector<sfgAlternativeChunk> sga;
	vector<sfgRemapChunk> sgr;

	unsigned long long channelCount;

	sfGroupChunk();
	int read(int frameblocksize);

	void write(int frameblocksize);
	void print();
};

class BASIC_API metadataChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	vector<sfGroupChunk> sfGroup;
	vector<objectChunk> object;
	vector<groupChunk> group;

	metadataChunk();
	int read(int frameblocksize);

	void write(int frameblocksize);
	void print(int frameblocksize);
};

class BASIC_API golombRiceData
{
public:
	int sign;
	unsigned long long B;
	int H;

	int read(int K);
};

class BASIC_API slcChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long waveformId;
	int L;
	int K;
	Int24 *sample;


	slcChunk();
	int read(int frameblocksize, int bitdepth);
	void compute(int frameblocksize);

	void write(int frameblocksize, int bitdepth);
	void print();
};

class BASIC_API silenceChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long waveformId;

	silenceChunk();
	int read(int frameblocksize, int bitdepth);

	void write(int frameblocksize, int bitdepth);
	void print();
};

class BASIC_API pcmChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	unsigned long long waveformId;
	Int24 *sample;

	pcmChunk();
	int read(int frameblocksize, int bitdepth);

	void write(int frameblocksize, int bitdepth);
	void print();
};


class BASIC_API audioChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	vector<pcmChunk> pcm;
	vector<silenceChunk> silence;
	vector<slcChunk> slc;

	audioChunk();
	int read(int frameblocksize, int bitdepth);

	void write(int frameblocksize, int bitdepth);
	void print();
};

class BASIC_API frameChunk
{
public:
	int chunkId;
	unsigned int chunkLength;
	int majorVersion;
	int minorVersion;
	int sampleRate;
	int frameBlockSize;
	int bitDepth;
	int isNewState;
	audioChunk audio;
	metadataChunk metadata;
	
	frameChunk();
	int read();

	void write();
	void print();
};


#endif  // CHUNK_H_
