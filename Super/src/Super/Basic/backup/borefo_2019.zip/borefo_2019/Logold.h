#ifndef V15PC_LOG_
#define V15PC_LOG_


//#ifdef _WIN32
//
//#ifdef BASIC_API_EXPORT
//#define BASIC_API __declspec(dllexport)
//#else
//#define BASIC_API __declspec(dllimport)
//#endif
//
//#else
//#define BASIC_API 
//#endif

//���Լ���dll�����ߣ�dllʹ���ߣ�ֱ����Ϊ��ͨ�ļ�������exe��������ĵ����趨--add by lizulin
//dll��������ĿԤ����BASIC_API_EXPORT 
//dllʹ������ĿԤ����BASIC_API_IMPORT
//��Ϊ��ͨ�ļ���exe������ֱ�Ӱ���ʹ�ã�����Ҫ����  (vs��,ճ����ctrl+z�����Զ���������Ԥ����)

#if defined(_WIN32)
	#if defined(BASIC_API_EXPORT)
		#define BASIC_API __declspec(dllexport)
	#elif defined(BASIC_API_IMPORT)
		#define BASIC_API __declspec(dllimport)
	#else
		#define BASIC_API 
	#endif
#else
	#define BASIC_API 
#endif



//#include "LogStruct.h"  //The original content is as follows
#include <vector>
#include <list>

typedef enum 
{
	LOG_ALL = 0,
	LOG_INF,
	LOG_WARNING,
	LOG_ERROR,
	LOG_SYSTEM,
	LOG_PLAY,
	LOG_END
}LOGTYPE;

typedef enum 
{
	LOG_CAT_ALL = 0,
	LOG_CAT_AUDIO_PIPELINE,
	LOG_CAT_WEB_CLIENT_UI,
	LOG_CAT_OBiA,
	LOG_CAT_END
}LOGCAT;
typedef enum 
{
	EXPORT_GDC=0,
	EXPORT_EXCEL,
	EXPORT_TEXT
}EXPORTTYPE;

typedef struct logDateTime{
	unsigned short year;
	unsigned char  month;
	unsigned char  day;
}LOGDATETIME;

typedef struct logTime
{
	unsigned char hour;
	unsigned char minute;
	unsigned char seconds;
}LOGDAYTIME;

typedef struct logQueryResult
{
	int type;
	int cat;
	std::string     time; //yyyy-mm-dd/hh:mm:ss   
	std::string     text;   
}LOGQUERYRESULT;

typedef std::vector<LOGQUERYRESULT> TLogQueryResultArray;
typedef std::list<std::string> TLogExportContextList;


/*
class ILogFileOperation
{
public:
	virtual int IsDirectory(const char* path) = 0;
	virtual int CreateDirectoryA(const char* path) = 0;
	virtual int DeleteDirectory(const char* path) = 0;
	virtual int OpenFile(const char* file) = 0;
	virtual int CloseFile() = 0;
	virtual int Write(const char* file,const int type,int nCat, const char* context) = 0;
	virtual int Read(const int type,int nCat, TLogQueryResultArray & result) = 0;
	virtual int Read(const int type, std::string & result) = 0;
};
*/
//class CLogFileOperation : public ILogFileOperation

class CLogFileOperation
{
public:
	CLogFileOperation(void);
	~CLogFileOperation(void);
public:
	int IsDirectory(const char* path);
	int CreateDirectoryA(const char* path);
	int DeleteDirectory(const char* path);
	int OpenFile(const char* file);
	int CloseFile();
	int Write(const char* file,const int type,int nCat, const char* context);
	int Read(const int type,int nCat, TLogQueryResultArray & result);
	int Read(const int type, std::string & result);
private:
	FILE* m_pfile;    //m_pfile
	FILE* fp_write;   //new
};



/*  //�򵥻�������
class BASIC_API ILog
{
public:
	virtual int Delete(LOGDATETIME * timeAfter, LOGDATETIME * timeBefore) = 0;
	virtual int Export(TLogQueryResultArray & contextList) = 0;
	virtual int Query(int type,int nCat, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore, TLogQueryResultArray & result) = 0;
	virtual std::string& Query(int type, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore) = 0;
	virtual int Write(int type,int nCat, const char *text) = 0;
};

BASIC_API ILog* CreateLog();
BASIC_API void ReleaseLog(ILog* pLog);
BASIC_API ILog* GetLogClass();
class CLog : public ILog
*/


class CLog
{
public:
	int Delete(LOGDATETIME * timeAfter, LOGDATETIME * timeBefore);
	int Export(TLogQueryResultArray & contextList);
	int Query(int type,int nCat,LOGDATETIME* timeAfter, LOGDATETIME* timeBefore, TLogQueryResultArray & result);
	int Write(int type,int nCat, const char *text);
	std::string& Query(int type, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore);
private:
	CLogFileOperation m_LogFileOp;
	std::string logString;
};

//BASIC_API CLog* GetLogClass();



#include "Thread.h"
//#include "ThreadSync.h"   //���λ�����
//#include "ringbuffer.h"   //���λ�����

//���������Ϊ�����߳�ģʽ�ͻ�����ģʽ



typedef struct _BufferLog_
{
	char buf[1*1024];
	unsigned int len;
}BufferLog;

template <typename T> class ringbuffer;

//�Լ�ʵ��һ���µ�Log��
class BASIC_API Log :public Thread
{
public:
	Log();
	~Log();
	void run();
public:
	int Delete(LOGDATETIME * timeAfter, LOGDATETIME * timeBefore);   //ɾ����־���ݲ�ʵ��
	int Export(TLogQueryResultArray & contextList); 
	int Query(int type,int nCat,LOGDATETIME* timeAfter, LOGDATETIME* timeBefore, TLogQueryResultArray & result);
	
	//ģʽ1--����д�߳�ģʽ
	int Write(int type,int nCat, const char *text);
	void sync();   //�������͸������
	//std::string& Query(int type, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore);


	//ģʽ2--�򵥶��̻߳�����ģʽ
    bool writeByMutex(int type,const char* text);
	FILE* fp_write;
private:
	CLogFileOperation m_LogFileOp;
	FILE* getFILE(unsigned int& ExistsFileSize);   //ͬʱ�����ļ�дָ��ͣ��Ѿ����ڵ��ļ���С��
	ringbuffer<BufferLog*>* ringbufferLog;
	
	//MyMutex mutex;
	class impl;
    impl* pimpl;
};

BASIC_API Log* GetLogClass();

BASIC_API int Test_Log();

#endif

