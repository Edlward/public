﻿// Log.cpp : 定义 DLL 的初始化例程。
//
#include "Log.h"
#include "../../public/Basic/MyBasicOperation.h"

#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//#ifdef _DEBUG
//	#define new DEBUG_NEW
//#endif
////在 MFC 中，可以使用 DEBUG_NEW 宏代替 new 运算符来帮助定位内存泄漏。 
////用 DEBUG_NEW分配的每个对象均将显示被分配 到的文件和行号，使您可以查明内存泄漏源。


#define MAX_PATH 1024
#define TRUE 1
#define FALSE 0






using namespace std;

/*
//FUNCLASS_API ILog* CreateLog()
 ILog* CreateLog()
{
	return new CLog;
}

void ReleaseLog(ILog* pLog)
{
	if (pLog != NULL)
		delete pLog;
}

CLog gLog;
ILog* GetLogClass()
{
	return &gLog;
}
*/

//CLog gLog;
//CLog* GetLogClass()
//{
//	return &gLog;
//}


Log gLog;
Log* GetLogClass()
{
	return &gLog;
}





//#define LOGROOT		getConfig().getLogRootPath()	
#define LOGROOT	".\\Log"
#define USBROOT	"e:"


int CLog::Delete(LOGDATETIME * timeAfter, LOGDATETIME * timeBefore)
{
	return 0;
}

int CLog::Export(TLogQueryResultArray & contextList)
{
#if 0
	time_t timep;
	time	(&timep);
	tm* p = localtime(&timep);
	char buft[MAX_PATH] = {0};
	string path = USBROOT;
	
	sprintf(buft,"%s\\%04d%02d%02d-%02d:%02d:%02d.log",
		path.c_str(),
		(1900+p->tm_year),(1+p->tm_mon),(p->tm_mday),
		p->tm_hour,p->tm_min,p->tm_sec);


	TLogQueryResultArray::iterator oIter;
	LOGQUERYRESULT itemdata;

	char tmp[10];
	char str[10];
	int nNum = 0;
	int nDay = 0;
	int nRet = 0;
	FILE* pf = NULL;
	char* pStr = str + 6;
	for (oIter = contextList.begin(); oIter != contextList.end(); oIter++)
	{
		itemdata = *oIter;
		memset(tmp,0,10);
		memset(str,0,10);
		memcpy(tmp,itemdata.time.c_str(),6);
		memcpy(str,itemdata.time.c_str(),8);

		if (nNum != atoi(tmp))
		{
			nNum = atoi(tmp);
			sprintf(buft,"%s\\%s",path.c_str(),tmp);
			m_LogFileOp.CreateDirectory(buft);
		}

		if (nDay != atoi(pStr))
		{
			nDay = atoi(pStr);
			if (pf != NULL){
				fclose(pf);
				pf = NULL;
			}
			memset(buft,0,MAX_PATH);
			sprintf(buft,"%s\\%s\\%s.log",path.c_str(),tmp,pStr);
			pf = fopen(buft,"a+");
		}

		if (pf != NULL){
			fprintf(pf,"%d %s %s",(int)itemdata.type,itemdata.time.c_str(),itemdata.text.c_str());
		}
	}

	if (pf != NULL){
		fclose(pf);
		pf = NULL;
	}
#else
	char buft[MAX_PATH] = {0};
	string path = USBROOT;
	string start, end;
	start = contextList.at(0).time;
	end = contextList.at(contextList.size() - 1).time;
	start.resize(8);
	end.resize(8);
	sprintf(buft,"%s\\%s-%s.log",
		path.c_str(),
		start.c_str(),
		end.c_str());
	FILE* pf = NULL;
	pf = fopen(buft,"a+");
	TLogQueryResultArray::iterator oIter;
	LOGQUERYRESULT itemdata;
	for (oIter = contextList.begin(); oIter != contextList.end(); oIter++)
	{
		itemdata = *oIter;
		if (pf != NULL){
			fprintf(pf,"%d %s %s\n",(int)itemdata.type,itemdata.time.c_str(),itemdata.text.c_str());
		}
	}
	if (pf != NULL){
		fclose(pf);
		pf = NULL;
	}
#endif
	return 0;
}


int CLog::Query(int type,int nCat, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore, TLogQueryResultArray & result)
{
	char buft[MAX_PATH] = {0};
	string path = LOGROOT;
	/*
	sprintf(buft,"%s\\%04d\\%02d",path.c_str(),timeAfter->year,timeAfter->month);
	if (!m_LogFileOp.IsDirectory(buft)){
		return 0;
	}

	memset(buft,0,MAX_PATH);
	sprintf(buft,"%s\\%04d\\%02d",path.c_str(),timeBefore->year,timeBefore->month);
	if (!m_LogFileOp.IsDirectory(buft)){
		return 0;
	}
*/
	int day = timeAfter->day;
	int month = timeAfter->month;
	int year = timeAfter->year;

	while (!((day - 1) == timeBefore->day 
		&& month == timeBefore->month 
		&& year == timeBefore->year))
	{
		memset(buft,0,MAX_PATH);
		sprintf(buft,"%s\\%04d\\%02d\\%02d.log",path.c_str(),year,month,day++);
		if (m_LogFileOp.OpenFile(buft)){		
			m_LogFileOp.Read(type,nCat,result);
			m_LogFileOp.CloseFile();
		}
		if(result.size()>2000)break;//最多返回2000条记录
		if (day == 31){
			day = 1;
			month++;
			if (month > 12){
				month = 1;
				year++;
				if (year > timeBefore->year){
					break;
				}
			}
		}
	}
	return 0;
}

std::string& CLog::Query(int type, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore)
{
	char buft[MAX_PATH] = {0};
	string path = LOGROOT;

	logString = "";
	int day = timeAfter->day;
	int month = timeAfter->month;
	int year = timeAfter->year;

	while (!((day - 1) == timeBefore->day 
		&& month == timeBefore->month 
		&& year == timeBefore->year))
	{
		memset(buft,0,MAX_PATH);
		sprintf(buft,"%s\\%04d\\%02d\\%02d.log",path.c_str(),year,month,day++);
#if 0
		if (m_LogFileOp.OpenFile(buft)){		
			m_LogFileOp.Read(type,logString);
			m_LogFileOp.CloseFile();
		}
		
		if (day == 31){
			day = 1;
			month++;
			if (month > 12){
				month = 1;
				year++;
				if (year > timeBefore->year){
					break;
				}
			}
		}
#else
		FILE *fp =fopen(buft, "rb");
		if(fp)
		{
			char buf[1030];
			fseek(fp, -1024, SEEK_END);
			int nread = fread(buf, 1, 1024, fp);
			buf[nread] = '\0';
			logString = buf;
			fclose(fp);
		}
#endif
	}
	return logString;
}


int CLog::Write(int type,int nCat, const char *text)
{
	time_t timep;
	time(&timep);
	tm* p = localtime(&timep);
	char buft[MAX_PATH] = {0};
	string path = LOGROOT;

	sprintf(buft,"%s\\%04d\\%02d",path.c_str(),(1900+p->tm_year),(1+p->tm_mon));

	if (!m_LogFileOp.IsDirectory(buft)){
		if (!m_LogFileOp.CreateDirectoryA(buft))
			return 0;
	}

	memset(buft,0,MAX_PATH);
	sprintf(buft,"%s\\%04d\\%02d\\%02d.log",path.c_str(),(1900+p->tm_year),(1+p->tm_mon),p->tm_mday);
	return m_LogFileOp.Write(buft,type,nCat,text); 
}




//#include <boost/filesystem/operations.hpp>
//#include <boost/filesystem/path.hpp>
//#include <boost/filesystem/convenience.hpp>
//#include <boost/filesystem/exception.hpp>
//#include <thread/activeThread/activeThread.h>
//#include <thread/activeThread/activeThreadManager_i.h>
//namespace fs = boost::filesystem;
//#include "LogFileOperation.h"


CLogFileOperation::CLogFileOperation(void)
{

}

CLogFileOperation::~CLogFileOperation(void)
{

}

int CLogFileOperation::IsDirectory(const char* path)
{
	//if(fs::is_directory(path)) 
    if(isDirectory(path)) 
		return TRUE;
	else
		return FALSE;
}


int CLogFileOperation::CreateDirectoryA(const char* path)
{
	std::string strDir(path);
	if (strDir[strDir.length()-1] != '\\')
	{
		strDir += '\\';
	}
	std::vector<std::string> vPath;
	std::string strTemp;
	bool bSuccess = false;

	for (unsigned int i=0;i<strDir.length();++i)
	{
		if (strDir[i] != '\\') 
		{
			strTemp += strDir[i];
		}
		else 
		{
			vPath.push_back(strTemp);
			strTemp += '\\';
		}
	}

	std::vector<std::string>::const_iterator vIter;

	for (vIter = vPath.begin(); vIter != vPath.end(); vIter++) 
	{
			std::string dir = *vIter;
			bSuccess =createDirectory(dir.c_str());    
			
			if (!bSuccess)
			{
				break;
			}

		//try{
		//	std::string dir = *vIter;
		//	bSuccess = fs::create_directories(*vIter);    
		//}
		//catch(fs::filesystem_error &err)
		//{
		//	printf("create directories error: %s\n", err.what());
		//}
	}

	return bSuccess;
}

int CLogFileOperation::DeleteDirectory(const char* path)
{
	bool ret=deleteDirectory(path);
	if (!ret)
	{
		return FALSE;
	}

	//try
	//{
	//	fs::remove_all(path);
	//}
	//catch(const fs::filesystem_error& e)
	//{
	//	printf("%s\n", e.what());
	//	return FALSE;
	//}

	return TRUE;
}

int CLogFileOperation::OpenFile(const char* file)
{
	m_pfile = fopen(file,"r");   //modify to rb ?
	if (m_pfile == NULL)
		return 0;
	return 1;
}

int CLogFileOperation::CloseFile()
{
	if (m_pfile != NULL){
		fclose(m_pfile);
	}
	return 0;
}

int CLogFileOperation::Write(const char* file,const int type,int nCat, const char* context)
{
	time_t timep;
	tm* p;
	time	(&timep);
	p = localtime(&timep);
	char buft[MAX_PATH] = {0};

	//每一次都打开关闭，太低效
	FILE* pf = fopen(file,"a+");
	if (NULL == pf){
		return 0;
	}

	fprintf(fp_write,"%d %d %04d%02d%02d-%02d:%02d:%02d %s\n",
		type,nCat,
		(1900+p->tm_year),(1+p->tm_mon),(p->tm_mday),
		p->tm_hour,p->tm_min,p->tm_sec,
		context);

	if (NULL != pf){
		fclose(pf);
	}

	return 1;
}

int CLogFileOperation::Read(const int type,int nCat, TLogQueryResultArray & result)
{
	char* pfile = NULL;
	char* pMove = NULL;
	char buf[MAX_PATH] = {0};
	char str[MAX_PATH] = {0};

	LOGQUERYRESULT res;
	while ((pfile = fgets(buf,MAX_PATH,m_pfile)))
	{
		res.type = (LOGTYPE)atoi(buf);
		pfile = strstr(buf," ");
		res.cat=atoi(pfile);
		pfile++;
		pfile = strstr(pfile," ");
		pfile++;
		pMove = strstr(pfile," ");
		memcpy(str,pfile,pMove - pfile);
		res.time = str;
		res.text = ++pMove;
		if (((LOGTYPE)type == LOG_ALL || (LOGTYPE)type == res.type)&&
			(nCat==LOG_CAT_ALL||nCat==res.cat)){
			result.push_back(res);
		}
	}

	return 0;
}

int CLogFileOperation::Read(const int type, std::string & result)
{
	char* pfile = NULL;
	char* pMove = NULL;
	char buf[MAX_PATH] = {0};
	char str[MAX_PATH] = {0};

	LOGQUERYRESULT res;
	while ((pfile = fgets(buf,MAX_PATH,m_pfile)))
	{
		if(buf[0] == '\0')
			break;
		res.type = (LOGTYPE)atoi(buf);
		pfile = strstr(buf," ");
		pMove = strstr(++pfile," ");
		memcpy(str,pfile,pMove - pfile);
		res.time = str;
		res.text = ++pMove;
		if ((LOGTYPE)type == LOG_ALL || (LOGTYPE)type == res.type)
		{
			//编译出错
			//result = result + res.time + " " + res.text + "\n";
			
			//改
			result +=res.time; 
			result +=" ";
			result +=res.text;
			result +="\n";
		}
	}

	return 0;
}
























#include "ringbuffer.h"   //环形缓冲区


class Log::impl
{
public:
	impl(){};
	~impl(){};
	MyMutex mutex;
};

Log::Log()
{
	pimpl=new impl;
	ringbufferLog=new ringbuffer<BufferLog*>(8);
}


Log::~Log()
{
	sync();
	stop(1000);

	delete ringbufferLog;
	delete pimpl;
}


int Log::Delete(LOGDATETIME * timeAfter, LOGDATETIME * timeBefore)
{
	return 0;
}

int Log::Export(TLogQueryResultArray & contextList)
{
	return 0;
}

int Log::Query(int type,int nCat,LOGDATETIME* timeAfter, LOGDATETIME* timeBefore, TLogQueryResultArray & result)
{

		char buft[MAX_PATH] = {0};
	string path = LOGROOT;
	/*
	sprintf(buft,"%s\\%04d\\%02d",path.c_str(),timeAfter->year,timeAfter->month);
	if (!m_LogFileOp.IsDirectory(buft)){
		return 0;
	}

	memset(buft,0,MAX_PATH);
	sprintf(buft,"%s\\%04d\\%02d",path.c_str(),timeBefore->year,timeBefore->month);
	if (!m_LogFileOp.IsDirectory(buft)){
		return 0;
	}
*/
	int day = timeAfter->day;
	int month = timeAfter->month;
	int year = timeAfter->year;

	while (!((day - 1) == timeBefore->day 
		&& month == timeBefore->month 
		&& year == timeBefore->year))
	{
		memset(buft,0,MAX_PATH);
		sprintf(buft,"%s\\%04d\\%02d\\%02d.log",path.c_str(),year,month,day++);
		if (m_LogFileOp.OpenFile(buft)){		
			m_LogFileOp.Read(type,nCat,result);
			m_LogFileOp.CloseFile();
		}
		if(result.size()>2000)break;//最多返回2000条记录
		if (day == 31){
			day = 1;
			month++;
			if (month > 12){
				month = 1;
				year++;
				if (year > timeBefore->year){
					break;
				}
			}
		}
	}
	return 0;
}

//std::string& Log::Query(int type, LOGDATETIME* timeAfter, LOGDATETIME* timeBefore)
//{
//	return "";
//}


const unsigned int NumBUF=8;
static unsigned int IndexBuf=0; 
static BufferLog GBBufferLog[NumBUF];
BufferLog* out=&GBBufferLog[0];  //IndexBuf++%NumBUF
//BufferLog* out=&GBBufferLog[IndexBuf%NumBUF];  //IndexBuf++%NumBUF

int Log::Write(int type,int nCat, const char *text)
{
    MyAutoLocker lock(pimpl->mutex);

	time_t timep;
	tm* p;
	time	(&timep);
	p = localtime(&timep);
	char buf[1024];
	sprintf(buf,"%d %d %04d%02d%02d-%02d:%02d:%02d %s\r\n",
		type,nCat,
		(1900+p->tm_year),
		(1+p->tm_mon),
		(p->tm_mday),
		p->tm_hour,
		p->tm_min,
		p->tm_sec,
		text);

	size_t lenLog=strlen(buf);
	if (out->len+lenLog>sizeof(out->buf))
	{
		ringbufferLog->push(out,false);
		out=&GBBufferLog[IndexBuf++%NumBUF];
		out->len=0;
	}
	else
	{
		memcpy(&out->buf[out->len],buf,lenLog);
		out->len+=lenLog;
	}
	//printf("Log::Write()=%s\n",buf);

	return -1;
#if 0

	time_t timep;
	tm* p;
	time	(&timep);
	p = localtime(&timep);

	//每一次都打开关闭，太低效
	//char buft[MAX_PATH] = {0};
	//FILE* pf = fopen(file,"a+");
	//if (NULL == pf){
	//	return 0;
	//}

	fprintf(fp_write,"%d %d %04d%02d%02d-%02d:%02d:%02d %s\n",
		type,nCat,
		(1900+p->tm_year),
		(1+p->tm_mon),
		(p->tm_mday),
		p->tm_hour,
		p->tm_min,
		p->tm_sec,
		text);

	//if (NULL != pf){
	//	fclose(pf);
	//}

	return 1;
#endif
}


void Log::sync()
{
    MyAutoLocker lock(pimpl->mutex);

	ringbufferLog->push(out,false);
}


void Log::run()
{
	while (getContinueRun())
	{
			//若打开的是已经存在的日志文件
			unsigned int orangelFileSize=0;
			FILE* fp=getFILE(orangelFileSize);
			unsigned int isWrittenSize=orangelFileSize;
			while (getContinueRun())
			{
				//fprintf(fp,"12347890000")
				//isWrittenSize+=fwrite(fp,1,100,fp);
				BufferLog* in=NULL;
				ringbufferLog->get(in,true);       //阻塞等待直到有日志
				
				isWrittenSize+=fwrite(in->buf,1,in->len,fp);
				::fflush(fp);	

				if (isWrittenSize>10*1024*1024)    //
				{
					fclose(fp);
					fp=getFILE(orangelFileSize);
					isWrittenSize=orangelFileSize;
				}
			}
			fclose(fp);
		}
}


FILE* Log::getFILE(unsigned int& ExistsFileSize)
{
	std::string logPath="C:";
	time_t timep;
	tm* p;
	time	(&timep);
	p = localtime(&timep);
	char buft[MAX_PATH] = {0};
	sprintf(buft,"%s\\%04d-%02d\\%02d.log",logPath.c_str(),(1900+p->tm_year),(1+p->tm_mon),p->tm_mday);		
	createDirectory(buft);  //路径不一定存在,先创建，若存在则直接返回

	std::string Path(buft);
	ExistsFileSize=0;
	if (isExistFile(Path.c_str()))
	{
		ExistsFileSize=getFileSize(Path.c_str());
	}

	//path="E:\\log.txt";
	FILE* fp=fopen(Path.c_str(),"ab");
	if(fp==NULL) 
	{
		printf("Error at: open log file %s\n",Path.c_str());	
		//return NULL;
		exit(-1);
	}
	return fp;
}


bool Log::writeByMutex(int type,const char* text)
{
#if 0
	time_t timep;
	tm* p;
	time	(&timep);
	p = localtime(&timep);

	//每一次都打开关闭，太低效
	//char buft[MAX_PATH] = {0};
	//FILE* pf = fopen(file,"a+");
	//if (NULL == pf){
	//	return 0;
	//}

	fprintf(fp_write,"%d %d %04d%02d%02d-%02d:%02d:%02d %s\n",
		type,
		(1900+p->tm_year),
		(1+p->tm_mon),
		(p->tm_mday),
		p->tm_hour,
		p->tm_min,
		p->tm_sec,
		text);

	//if (NULL != pf){
	//	fclose(pf);
	//}
#endif

	return true;
}

int Test_Log()
{
	//createDirectory(".\\123\\456\\789\\");
	GetLogClass()->start();
	for (int i=0;i<100*1024;i++)
	{
		char str[500];
		sprintf(str, "Log Test1234567890=%d",i);
		GetLogClass()->Write(LOG_SYSTEM, LOG_CAT_OBiA,str);
	}

	return 0;
}

