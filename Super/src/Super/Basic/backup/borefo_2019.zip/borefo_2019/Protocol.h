﻿#ifndef PROTOCOL_H
#define PROTOCOL_H


#pragma pack(push,1)     //设置一个字节对齐  
typedef struct _KL_
{
	unsigned short head;         //报文头  0x7585  0x7587?;
	unsigned short key;           //报文类型  
//	unsigned short len;           //报文长度  不包括此头  ID为16bits。
	unsigned int len;               //为了传送大文件，改int类型
} KL;
#pragma pack(pop)       //恢复原来对齐状态
 


typedef enum
{   
    KL_HEAD=0x7585,             //数据报文头
    ZERO=0x0000                 //填充cmd_Sub
}ETYPE_TEST; 


//与声道定义的SL重命名了，改名为SLV
typedef struct _SLV_
{
	unsigned short m_sID;
	unsigned short m_length;
} SLV; 


 

 


//客户端类型枚举，MPU用来区分客户端类型   Protool插件，Monitor,MPU UI
typedef struct _ClientType_
{
	int ClientType;
}ClientType;

enum EMClientType
{
	CLIENT_UNKNOW=0x10,    //初始化时的未知状态
	CLIENT_PANNER,     //protool插件
	CLIENT_MONITOR,   //monitor
	CLIENT_MPUUI,        //mpu ui
	CLIENT_DCAPUI,       //mpu ui
	CLIENT_DESIGNER    //待添加
};

enum StringID
{
	CONTENT_ID = 0x80,
	CONTENT_NAME,
	CONTENT_PROGRESS,
	CONTENT_STATUS,
	CONTENT_FORMAT,
	CONTENT_FILMLENGTH,
	CONTENT_PROGRAMLENGTH,
	CONTENT_STEREOSCOPIC,
	CONTENT_ISSUER,
	CONTENT_ISSUEDATE,
	CONTENT_TIMERANGE,
	CONTENT_RECVSEGMENT,
	CONTENT_TOTALSEGMENT,
	CONTENT_RECV_DATETIME,
	CONTENT_LOCATE,

	CONTENT_PATH_SRC,   //源路址
	CONTENT_PATH_DST,   //目路址
};

enum PROTOCOL 
{
	//协议汇总
	//定义新报文的时候，可以暂不指定key的值, 只需要确认枚举名，  在对接时候同步此enum PROTOCOL结构  即可
	//待项目稳定时候再填充协议key值,

	//MPU与MPUUI,MONITOR,PANNER共用的通讯协议
	CMD_SET_CLIENTTYPE=0X1000,          //用在MPU的Server区分Client类型
	CMD_SET_CLIENTTYPE_RESP,

	//MPU与Panner的通信
	CMD_PLAY_STATUS_CHANGED=0X2000,
	CMD_PLAY_STATUS_CHANGED_RESP,
	CMD_GET_AVAILABILITY_ID,            //向MPU请求ID池中可用的ID列表
	CMD_AVAILABILITY_ID_LIST,            //返回MPU ID池中可用的ID列表
	CMD_SELECT_ID,                              //通知MPU使用ID池中的ID
	CMD_SELECT_ID_RESP,                     //MPU确认使用ID
	CMD_RELEASE_ID,                            //通知MPU释放已占用的ID
	CMD_RELEASE_ID_RESP,                   //MPU确认释放ID
	CMD_SET_METADATA,                     //向MPU发送Metadata
	CMD_SET_METADATA_RESP,           //MPU收到Metadata后反馿
	CMD_SET_TIME_CODE,                    //单独设置Protool播放时间码
	CMD_SET_TIME_CODE_RESP,

	//MPU与Monitor的通信
	CMD_GET_METADATA_LIST=0x3000,       //Monitor向MPU发送Metadata请求
	CMD_GET_METADATA_LIST_RESP,           //MPU向Monitor返回MetadataList
	CMD_GET_SPEAKER_LIST,                         //Monitor向MPU发送SpeakerList请求
	CMD_GET_SPEAKER_LIST_RESP,               //MPU向Monitor返回SpeakerList
	CMD_GET_ROOMDIM,                             //Monitor向MPU发送Room尺寸请求
	CMD_GET_ROOMDIM_RESP,                     //MPU向Monitor返回Room尺寸
 

	//未添加到设计方案
	CMD_GET_SPEAKER_GAIN,            //实时取扬声器音量
	CMD_GET_SPEAKER_GAIN_RESP,   //返回SPEAKER_GAIN结构32个，64，128第一个int存放扬声器个数n，后面跟着n个float


	//MPU与Designer之间的通讯
	CMD_PLAY_CALIBRATE_PINKNOISE=0x4000,      //通知MPU播放指定的PinkNoise用于校准MIC，只在中置通道中播政
	CMD_PLAY_CALIBRATE_PINKNOISE_RESP,          //0x0024	1	0房	MPU确认播放＿失败＿成功
	CMD_STOP_CALIBRATE_PINKNOISE,	                  //0x0025	0	0	通知MPU停止播放用于校准MIC的PinkNoise
	CMD_STOP_CALIBRATE_PINKNOISE_RESP,	          //0x0026	0	0	MPU确认停止播放用于校准MIC的PinkNoise
	CMD_SET_CALIBRATE_PINKNOISEGAIN,	          //Gain(float)	通知MPU设置用于校准MIC的PinkNoise的Gain
	CMD_SET_CALIBRATE_PINKNOISEGAIN_RESP,     //10房	MPU确认停止播放用于校准MIC的PinkNoise
	CMD_PLAY_PINKNOISE,                                      //向MPU请求在指定Speaker上播放粉噪，注意，每次只能在一个音箱上放粉噿
	CMD_PLAY_PINKNOISE_RESP,                             //MPU确认在指定Speaker上播放粉噿
	CMD_STOP_PINKNOISE,                                     //向MPU请求停止在指定Speaker上播放粉噿
	CMD_STOP_PINKNOISE_RESP,                            //MPU确认在指定Speaker上停止播放粉噿
	CMD_START_AUTOEQ,                   
	CMD_START_AUTOEQ_RESP,   
	CMD_UPDATE_AUTOEQRESULT,
	CMD_UPDATE_AUTOEQRESULT_RESP,
	CMD_STOP_AUTOEQ,
	CMD_STOP_AUTOEQ_RESP,
	CMD_GET_AUTOEQPROGRESS,
	CMD_GET_AUTOEQPROGRESS_RESP,
	CMD_GET_EQSTATE,                           //取自动均衡结果
	CMD_GET_EQSTATE_RESP,
	CMD_GET_ALLEQGAIN,                     //Designer 用不到
	CMD_GET_ALLEQGAIN_RESP,                //Designer 用不到
	CMD_ENABLE_MICSINPUT,                //设置麦克风使能
	CMD_ENABLE_MICSINPUT_RESP,
	CMD_GET_MICSMETER,                     //取麦克风音量
	CMD_GET_MICSMETER_RESP,           
	CMD_GET_FADER,                             //进入AutoEQ页面的时候取feder值
	CMD_GET_FADER_RESP,
	CMD_SET_FADER,                             //fader值变化的时候向mpu发送
	CMD_SET_FADER_RESP,
	CMD_ENABLE_EQ,                       //控制EnableEQ的使能       
	CMD_ENABLE_EQ_RESP,   

	CMD_MANUAL_EQ_SETGAIN,
	CMD_MANUAL_EQ_SETGAIN_RESP,

	CMD_MANUAL_EQ_SETPATTEN,
	CMD_MANUAL_EQ_SETPATTEN_RESP,


	//MPU与MPU-UI与通信协议
	//MPUUI与Monitor的Transport控制和mute，dim功能共用以下协议
	CMD_SET_MUTESTATE=0X5000,
	CMD_GET_MUTESTATE,
	CMD_MUTESTATE_RESP,
	CMD_SET_DIMSTATE	,
	CMD_GET_DIMSTATE,
	CMD_DIMSTATE_RESP,
	CMD_SET_LTCSTATE,
	CMD_GET_LTCSTATE,
	CMD_LTCSTATE_RESP,
	CMD_SET_PLAYSTOPSTATE,
	CMD_GET_PLAYSTOPSTATE,
	CMD_PLAYSTOPSTATE_RESP,
	CMD_SET_RECORDSTATE,
	CMD_GET_RECORDSTATE,
	CMD_RECORDSTATE_RESP,
	CMD_SET_ACTIVE_MACRO,
	CMD_SET_ACTIVE_MACRO_RESP,
	
	
	//add by lizulin  MPU-UI与Mpu_Core  Dcap-UI与Dcap-Core  设置音量共用以下命令
	CMD_SET_ALL_VALUME,   //设置总音量，声卡SoundPlay所有声道输出乘以valume再输出
	CMD_SET_ALL_VALUME_RESP,
	
	
	

	//DAC文件操作, AutoEQ功能，MPU与Designer,MPU UI以下此命令
	CMD_SET_DAC=0X5100,      //获取/发送DAC配置文件，就是xml配置文件
	CMD_SET_DAC_RESP,
	CMD_GET_DAC,                    
	CMD_GET_DAC_RESP,
	CMD_RESET_DAC,
	CMD_RESET_DAC_RESP,

	//CMD_SET_EQGAIN,
	//CMD_SET_EQGAIN_RESP,


	//其他窗口简单命令
	CMD_SET_SETTING=0X5200,
	CMD_SET_SETTING_RESP,
	CMD_GET_SETTING,
	CMD_GET_SETTING_RESP,
	CMD_REBOOT_MPU,
	CMD_REBOOT_MPU_RESP,
	CMD_GETINFO,
	CMD_GETINFO_RESP,
	CMD_GET_LOG,
	CMD_GET_LOG_RESP,
	CMD_GET_LOG_DOWNLOAD_URL,
	CMD_GET_LOG_DOWNLOAD_URL_RESP,
	CMD_SET_RECORD_LTC,    //设置录制模式与protools时间码同步
	CMD_SET_RECORD_LTC_RESP,

	//工程与编码相关命令
	CMD_EXPORT_PROJECT=0x5300,
	CMD_EXPORT_PROJECT_RESP,

	CMD_GET_DRIVER_LIST,
	CMD_GET_DRIVER_LIST_RESP,
	CMD_GET_PROJECT_LIST,
	CMD_GET_PROJECT_LIST_RESP,
	CMD_NEW_PROJECT,
	CMD_NEW_PROJECT_RESP,
	CMD_OPEN_PROJECT,
	CMD_OPEN_PROJECT_RESP,
	CMD_DEL_PROJECT,
	CMD_DEL_PROJECT_RESP,
	CMD_SAVE_PROJECT,
	CMD_SAVE_PROJECT_RESP,
	CMD_CLOSE_PROJECT,
	CMD_CLOSE_PROJECT_RESP,
	CMD_COPY_PROJECT,
	CMD_COPY_PROJECT_RESP,
	CMD_COPY_PROJECT_PROGRESS,
	CMD_COPY_PROJECT_PROGRESS_RESP,
	CMD_START_ENCODER,
	CMD_START_ENCODER_RESP,
	CMD_ENCODER_PROGRESS,
	CMD_ENCODER_PROGRESS_RESP,

	CMD_SAVE_PROJECT_AS,
	CMD_SAVE_PROJECT_AS_RESP,

	CMD_GET_PROJECTXML,
	CMD_GET_PROJECTXML_RESP,
	CMD_SET_PM_OR_MXF,
	CMD_SET_PM_OR_MXF_RESP,
	CMD_UNSET_PM_OR_MXF,
	CMD_UNSET_PM_OR_MXF_RESP,

	CMD_GET_MXF_LIST,
	CMD_GET_MXF_LIST_RESP,

	CMD_GET_CURRENT_PROJECT,
	CMD_GET_CURRENT_PROJECT_RESP,

	CMD_SET_DOWNMIX_ENABLE,
	CMD_SET_DOWNMIX_ENABLE_RESP,
	CMD_GET_DOWNMIX_STATUS,
	CMD_GET_DOWNMIX_STATUS_RESP,










	//DCAP界面和Core交互命令
	//add by zhangjing
	CMD_GET_MACRO_CONFIG=0X6100,
	CMD_GET_MACRO_CONFIG_RESP,
	CMD_SET_MACRO_CONFIG,
	CMD_SET_MACRO_CONFIG_RESP,

	CMD_GET_EQ_CONFIG=0X6200,
	CMD_GET_EQ_CONFIG_RESP,
	CMD_SET_EQ_CONFIG,
	CMD_SET_EQ_CONFIG_RESP,
	CMD_DEL_EQ_CONFIG,
	CMD_DEL_EQ_CONFIG_RESP,
	CMD_GET_EQ_NAME,
	CMD_GET_EQ_NAME_RESP,
	CMD_FLATTEN,
	CMD_FLATTEN_RESP,
	CMD_SET_OUT_LEVEL,
	CMD_SET_OUT_LEVEL_RESP,
	CMD_SET_EQ_OF_CHANNEL,
	CMD_SET_EQ_OF_CHANNEL_RESP,

	CMD_GET_MIX_CONFIG = 0X6300,
	CMD_GET_MIX_CONFIG_RESP,
	CMD_SET_MIX_CONFIG,
	CMD_SET_MIX_CONFIG_RESP,
	//end

	//ADD BY YCS
	CMD_SET_FADE=0X6800,
	CMD_SET_FADE_RESP,
	CMD_GET_FADE,
	CMD_GET_FADE_RESP,



	CMD_SYS_LOGIN =0x7000,
	CMD_SYS_LOGIN_RESP,
	CMD_SYS_LOGOUT,
	CMD_SYS_LOGOUT_RESP,
	CMD_SYS_GET_USERINF,
	CMD_SYS_GET_USERINF_RESP,
	CMD_SYS_MODIFY_USERINF,
	CMD_SYS_MODIFY_USERINF_RESP,
	CMD_SYS_DELETE_USER,
	CMD_SYS_DELETE_USER_RESP,
	CMD_SYS_CREATE_USER,
	CMD_SYS_CREATE_USER_RESP,
	CMD_SYS_GET_LOG,
	CMD_SYS_GET_LOG_RESP,


	CMD_SYS_GET_NETINF=0X7100,
	CMD_SYS_GET_NETINF_RESP,
	CMD_SYS_SET_NETINF,
	CMD_SYS_SET_NETINF_RESP,
	CMD_SYS_BACKUP,
	CMD_SYS_BACKUP_RESP,
	CMD_SYS_RESTORE,
	CMD_SYS_RESTORE_RESP,
	CMD_SYS_RESET,
	CMD_SYS_RESET_RESP,
	CMD_SYS_UPDATE,
	CMD_SYS_UPDATE_RESP,

	CMD_SYS_REBOOT=0X7200,
	CMD_SYS_REBOOT_RESP,

	CMD_SYS_FILE_TRANS=0X7300,
	CMD_SYS_FILE_TRANS_RESP,

	//ADD END.   YCS

	//Content Manager
	CMD_UPDATE_PROGRAM_LIST_HDD = 0x8000,
	CMD_UPDATE_PROGRAM_LIST_HDD_RESP,
	CMD_UPDATE_PROGRAM_LIST_USB,
	CMD_UPDATE_PROGRAM_LIST_USB_RESP,
	CMD_IS_PROGRAM_LIST_READY_HDD,
	CMD_IS_PROGRAM_LIST_READY_HDD_RESP,
	CMD_IS_PROGRAM_LIST_READY_USB,
	CMD_IS_PROGRAM_LIST_READY_USB_RESP,
	CMD_GET_PROGRAM_LIST_HDD,
	CMD_GET_PROGRAM_LIST_HDD_RESP,
	CMD_GET_PROGRAM_LIST_USB,
	CMD_GET_PROGRAM_LIST_USB_RESP,

	CMD_COPY_PROGRAM,
	CMD_COPY_PROGRAM_RESP,
	CMD_GET_COPY_PROGRESS,
	CMD_GET_COPY_PROGRESS_RESP,
	CMD_DELETE_PROGRAM,
	CMD_DELETE_PROGRAM_RESP,

	//CMD_START表示各个子窗口命令的起始倿
	CMD_UI_BEGIN=0X9000,
	CMD_UI_END,
};
 
 

//(28*4)*128byte 大约14k   
class ObjMetaData    //对象元数据结构，在panner，moitor,core共用
{
public:
	int id;
	unsigned int timecode;   //改unsigned int
	float positionX;  // x
	float positionY;  // y
	float positionZ;  // z
	float extent;
	float gain;
	float coherence;
	float snap;
	float zoneGain[19];
	ObjMetaData()
	{
		timecode = 0;
		positionX = 0;  // x
		positionY = 0;  // y
		positionZ = 0;  // z
		extent = 0;
		gain = 0;
		coherence = 0;
		snap = 0;
		for(int i = 0; i < 19; i++)
		{
			zoneGain[i] = 0;
		}
	}
};

 

typedef struct  _SPeaker_
{
public:
	float x;
	float y;
	float z;
    float sound_loud;
    int   channel;
    char name[10];     //30*128
}SPeaker;



//【room】为MPU Core向Monitor传递的影厅尺寸信息，数据结构定义如下：
typedef struct  _DIM_
{
    float x;
    float y;
    float z;
}DIM;


//【SpeakerList】SpeakerList为MPU Core向Monitor传送的n个音箱（包含10个BED）的XYZ坐标、SoundLoud、channel及音箱名字定义，数据结构如下。
//10个BED的音箱名字定义分别为L，R，C，LFE，Lss，Rss，Lsr，Rsr，Lts，Rts。

enum{
	C_ID = 0,
	C_NAME,
	C_PROGRESS,
	C_STATUS,
	C_FORMAT,
	C_FILM_LENGTH,
	C_PROGRAM_LENGTH,
	C_STEREO,
	C_ISSUER,
	C_ISSUEDATE,
	C_TIMERANGE,
	C_RECVSEGMENT,
	C_TOTAL_SEGMENT,
	C_RECV_DATETIME,
	C_LOCATE,
};

#if 0
struct InfoData
{
public:
	std::string  pData[16];
/*  The details which there are display on UI
	"Film ID:",  0
	"Content Name:", 1
	"Progress:", 2
	"Receive Status:", 3
	"Video Format:", 4
	"Content Size:", 5
	"Duration:", 6 
	"2D/3D:", 7
	"Issuer:", 8
	"Issue Date:",
	"Time Range:",
	"PKL file:",
	"Issue Area:",
	"Receive Date:",
	"Full Path:",
	"Creator",

	enum{
	C_ID = 0,
	C_NAME,
	C_PROGRESS,
	C_STATUS,
	C_FORMAT,
	C_FILM_LENGTH,
	C_PROGRAM_LENGTH,
	C_STEREO,
	C_ISSUER,
	C_ISSUEDATE,
	C_TIMERANGE,
	C_RECVSEGMENT,
	C_TOTAL_SEGMENT,
	C_RECV_DATETIME,
	C_LOCATE,
	};
*/ 
}; 
#endif



#endif






