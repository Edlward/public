﻿#ifndef RINGBUFFERPROCESS_H_
#define RINGBUFFERPROCESS_H_
//#include "ringbufferProcess.h"   //跨进程环形缓冲区


/*ringbuffer类模板  20150812  王领
定义windows环境下的环形缓冲区,适用于多个生产者，多个消费者，多个缓冲区的情况。
当缓冲区为满时，写入函数(push())会阻塞并进入等待队列。
当缓冲区为空时，读取函数(get( ))会阻塞并进入等待队列。
当出现饿死的线程时，使用TerminateThread(handle, -1) 结束该线程，并执行clear()函数。
为了减少数据复制的开销，本缓冲区内存储的是指向数据的指针。
在正常使用时，存储指针或者直接存储数据无区别。但是当调用clear函数或者析构函数时，
需要额外对指针进行释放操作。
*/

//refactoring  by lizulin 李祖林 重构
//重构改封装跨平台的信号量，互斥量 
#include <iostream>
#include <string>
#include "ThreadSync.h"
#include "ThreadSync.cpp"   //同时包含实现文件才能例化模板,否则所有类必须在.h文件实现

#include "ShareMemory.h"
#include "ShareMemory.cpp" 

//using namespace Super;

//改通过命名信号量，实现跨进程的ringbufer，一个进程里面push，另一个进程里面get，
//通过共享内存实现数据交互

#if 0
#include <windows.h>
#include <process.h>
#include <iostream>
#endif

//using namespace std;



//改通过命名信号量，实现跨进程的ringbufer，一个进程里面push，另一个进程里面get，
//通过共享内存实现数据交互
template <class T>
class ringbufferProcess
{
private:
	T *pData;                                              // 存放数据的指针
	unsigned int BufferSize;                        // 缓冲区大小
	//int WriteIndex;                                   // 当前写入位置
	//int ReadIndex;                                   // 当前读取位置
	//int count;									         //记录有效货物数量 A count for judge buffer empty or not
  
	//读写可能在不同线程，需要把一些计数器变量在进程间共享，考虑避免多次初始化问题
	typedef struct _ShareCount_
	{
		int initKey;                                                         //创建者标记，决定是否初始化以下变量
		unsigned int BufferSize;                                    // 缓冲区大小
		unsigned int WriteIndex;                                   // 当前写入位置
		unsigned int ReadIndex;                                   // 当前读取位置
		int count;									                        //记录有效货物数量 A count for judge buffer empty or not
	}ShareCount;
	ShareCount* pSC;
	//HANDLE semaphoreBufferEmpty;    // 缓冲区有空间的信号量
	//HANDLE semaphoreBufferFull;        // 缓冲区有货物的信号量
	//CRITICAL_SECTION lock;                 // 临界区锁
	MySemaphore mySemaphoreBufferEmpty;
	MySemaphore mySemaphoreBufferFull;
	MyMutex m_mutex;                              //一般互斥互斥锁效率高，windows基于临界区
	MyProcessMutex m_ProcessMutex;      //跨进程使用进程间互斥锁，当本类作为跨进程使用时候
	MapShareMemory m_ShareMem;
public:
	inline ringbufferProcess(const unsigned int bufferSize = 128,const char* name=NULL);
	//ringbuffer(const int bufferSize = 128,const char* name=NULL);
	inline ~ringbufferProcess();

	// 往缓冲区写数据,flag为true，则无限等待，false则有限时间内没有空位则丢弃数据
	inline bool push(const T& cargo, bool flag = true);           //为了效率用引用
	inline bool get(T& cargo,bool flag = true);           
	//T get(bool flag = true); //返回NULL不科学，如果是整数缓冲区null为0是有意义的

	//往缓冲区读写数据 以timeout作为延时,time=0XFFFFFFFF则无限等待
	inline bool push(const T& cargo,unsigned int timeout);      //不能设定默认参数，否则调用不明确
	inline bool get(T& cargo,unsigned int timeout);     

/*
	//跨进程传递共享内存指针使用,推送指针前转成相对地址在推送,取到指针后再映射成本进程指针可以直接使用--只能在跨进程中传递同名共享内存指针
	inline bool PushShareMemPoint(const T cargo, bool flag = true); // 往缓冲区写数据,flag为true，则无限等待，false则有限时间内没有空位则丢弃数据
	inline bool GetShareMemPoint(T& cargo,bool flag = true);          // 取出缓冲区数据,flag为true，则无限等待，false则有限时间内没取到数据返回空
	void* pShareMem;     //共享内存在本进程映射地址
	inline void setShareMemPoint(void* p);
*/
    inline unsigned int getTotalSize(){return pSC->BufferSize;}     // 返回总缓冲区大小，初始化时候决定
	inline unsigned int getWritePos(){return pSC->WriteIndex;}    // 获取写入位置
	inline unsigned int getReadPos(){return pSC->ReadIndex;}     // 获取读取位置
	inline bool IsFull()
    {
        if(pSC->count >=BufferSize){return true;}
        return false;
    }
    unsigned int getSize(){return pSC->count;}     // 返回缓冲区货物剩余个数 等于写入个数减去读取个数
	inline bool clear(bool flag = true);                  // 清空缓冲区--flag为true表明存放的是new出来的指针,需要释放
};

template <class T>
//ringbuffer<T>::ringbuffer(const int bufferSize,const char* name) : // 构造函数
//	mySemaphoreBufferEmpty(bufferSize,bufferSize,name)
//	,mySemaphoreBufferFull(0,bufferSize,name)
ringbufferProcess<T>::ringbufferProcess(const unsigned int bufferSize,const char* name=NULL): // 构造函数
	mySemaphoreBufferEmpty(bufferSize,bufferSize,std::string(std::string(name)+"_Empty").c_str())
	,mySemaphoreBufferFull(0,bufferSize,std::string(std::string(name)+"_Full").c_str())
	,m_ProcessMutex(std::string(std::string(name)+"_mutex").c_str())
	,m_ShareMem(bufferSize*sizeof(T)+sizeof(ShareCount),std::string(std::string(name)+"_privateMem").c_str())
{
	BufferSize = bufferSize;
	//if(bufferSize <= 0)
	//{
	//	std::cout<<"Can not creat a buffer without storage!\nSo we creat a buffer with 128 storages!"<<std::endl;
	//	bsize = 128;
	//}

	//semaphoreBufferEmpty = CreateSemaphore(NULL, bsize, bsize, NULL);    //初始赋予的信号值  允许的最大的信号值
	//semaphoreBufferFull = CreateSemaphore(NULL, 0, bsize, NULL);
	//InitializeCriticalSection(&lock);

	//WriteIndex = 0;
	//ReadIndex = 0;
	//count = 0;

	//count = BufferSize;
	//pData = new T[BufferSize];
	//用共享内存构造对象
	void* pShare=m_ShareMem.getAddress();
	//pData=operator new(pShare) T[BufferSize];
	pData=(T*)pShare;

	//进程间共享计数器的初始化
	pSC=(ShareCount*)((char*)pShare+bufferSize*sizeof(T));
	if (pSC->initKey!=0X08250512)
	{
		pSC->WriteIndex=0;                                   // 当前写入位置
		pSC->ReadIndex=0;                                   // 当前读取位置
		pSC->count=0;	
		pSC->initKey=0X08250512;
	}


	//for(int i = 0; i < BufferSize; i++)
	//{
	//	pData[i] = NULL;
	//}
}

template <class T>
ringbufferProcess<T>::~ringbufferProcess()  // 析构函数
{
	for(int i = 0; i < BufferSize; i++)  // 若放的不是指针，这句话删去
	{
		//if(data[i] != NULL)
		//delete data[i];
	}
	
	//delete[]  pData;

	//共享内存不需要释放，只需要构造析构函数即可--一般也不需要，因为在只能在进程中传递基础类型，不能传递std::string之类的结构
	for(int i = 0; i < BufferSize; i++)  // 若放的不是指针，这句话删去
	{
          pData[i].~T();    //如何显示调用模板类型的析构函数
	}



	//CloseHandle(semaphoreBufferEmpty);  
	//CloseHandle(semaphoreBufferFull);  


	//DeleteCriticalSection(&lock); 

	//printf("ringbuffer 析构\n");
}


template <class T>
bool ringbufferProcess<T>::push(const T& cargo, bool flag)  // 往缓冲区放数据
{
	unsigned int timeout=5;   //默认5ms 
	if(flag==true)
	{
		timeout=0XFFFFFFFF;    //INFINITE; //无限等待
	}
	return push(cargo,timeout);
}

template <class T>
//T ringbufferProcess<T>::get(bool flag = true)  // 取出缓冲区数据
bool ringbufferProcess<T>::get(T& cargo,bool flag)  // 取出缓冲区数据
{
	unsigned int timeout=5;    //默认5ms ，经测量时间在毫秒精度范围是精确的
	if(flag==true)
	{
		timeout=0XFFFFFFFF;     //INFINITE;  //无限等待
	}
	return get(cargo,timeout);
}


template <class T>
bool ringbufferProcess<T>::push(const T& cargo,unsigned int timeout)
{
	//if(WAIT_TIMEOUT == WaitForSingleObject(semaphoreBufferEmpty, 40))
	if(mySemaphoreBufferEmpty.Wait(timeout)==false)
	{
		return false;
	}

	//EnterCriticalSection(&lock);   // 获取临界区锁

	m_ProcessMutex.Lock();

	pData[pSC->WriteIndex] = cargo;

	//pSC->WriteIndex = (pSC->WriteIndex + 1) % BufferSize;
    
    //没有取余除法操作更快
    int Index=pSC->WriteIndex + 1;
    if (Index>=BufferSize)
    {
        Index=0;
    }
    pSC->WriteIndex=Index;
	
    pSC->count++;

	m_ProcessMutex.UnLock();

	//LeaveCriticalSection(&lock);  // 释放临界区锁
	mySemaphoreBufferFull.Signal();
	//ReleaseSemaphore(semaphoreBufferFull, 1, NULL);  // 释放有货物的信号量
	return true;
}

template <class T>
bool ringbufferProcess<T>::get(T& cargo,unsigned int timeout)
{
	//if(WAIT_TIMEOUT == WaitForSingleObject(semaphoreBufferFull, 40))
	if(mySemaphoreBufferFull.Wait(timeout)==false)
	{
		//return NULL;  //不科学
		return false;
	}

	//EnterCriticalSection(&lock);   // 获取临界区锁
	//mutex.Lock();
	m_ProcessMutex.Lock();


	//T cargo = pData[ReadIndex];
	cargo = pData[pSC->ReadIndex];

	//pData[pSC->ReadIndex] = NULL;  // 若放的不是指针，这句删去

	//pSC->ReadIndex = (pSC->ReadIndex + 1) % BufferSize;
    //没有取余除法操作更快
    int Index=pSC->ReadIndex + 1;
    if (Index>=BufferSize)
    {
        Index=0;
    }
    pSC->ReadIndex=Index;


	pSC->count--;	

	//mutex.UnLock();
	m_ProcessMutex.UnLock();

	//LeaveCriticalSection(&lock);  // 释放临界区锁
	//ReleaseSemaphore(semaphoreBufferEmpty, 1, NULL);  // 释放有空的缓冲区的信号量
	mySemaphoreBufferEmpty.Signal();
	//return cargo;
	return true;
}

template <class T>
bool ringbufferProcess<T>::clear(bool flag = true)  // 清空缓冲区
{
	//return true;
	//ReleaseSemaphore(semaphoreBufferEmpty, 1, NULL);  // 释放有空的缓冲区的信号量
	//_sleep(50);
	//EnterCriticalSection(&lock);   // 获取临界区锁

	//mutex.Lock();
	m_ProcessMutex.Lock();
#if 0
	if(true==flag)  // 若放的是new指针
	{
		for(int i = 0; i < bsize; i++)  // 若放的不是指针，这句话删去
		{
			if(data[i] != NULL)
			{
				delete data[i];
			}
		}
	}
#endif
	//delete[] data;

	//CloseHandle(semaphoreBufferEmpty);  
	//CloseHandle(semaphoreBufferFull);  
	//DeleteCriticalSection(&lock); 

	//semaphoreBufferEmpty = CreateSemaphore(NULL, bsize, bsize, NULL);
	//semaphoreBufferFull = CreateSemaphore(NULL, 0, bsize, NULL);

	//InitializeCriticalSection(&lock);

	//重新按照初始状态构造信号量
	//mySemaphoreBufferEmpty.ReInit();
	//mySemaphoreBufferFull.ReInit();

	mySemaphoreBufferEmpty.ReSet();  //可能死锁？
    mySemaphoreBufferFull.ReSet();

	//读写位置复位
	pSC->WriteIndex = 0;
	pSC->ReadIndex = 0;
	pSC->count=0;	

	//mutex.UnLock();
    m_ProcessMutex.UnLock();


#if 0
	data = new T[bsize];
	if(true==flag)  // 若放的是NEW指针
	{
		for(int i = 0; i < bsize; i++)  // 若放的不是指针，这句话删去
		{
			data[i] = NULL;
		}
	}
#endif


	return true;
}


//显示实例化
//template class ringbufferProcess<int>;
//template class ringbufferProcess<cardInput*>;



//typedef ringbufferProcess<int> ringbufferProcessInt;
//typedef ringbufferProcess<cardInput> ringbufferProcessIntcardInputP;
//




#endif // RINGBUFFER_H_