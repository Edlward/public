﻿//#include "ShareMemory.h"

#ifndef  SHAREMEMORY_CPP
#define  SHAREMEMORY_CPP








#endif



