﻿#ifndef  SHAREMEMORY_H
#define  SHAREMEMORY_H
#include "global.h"
#include <iostream>

//因为被processringbuf模板用到，声明与实现都放头文件里面,而且定义为inline函数，
//否则如果在一个程序两个地方实例化同类型的processringbuf模板时，链接错误
//原因是被重复实例化了，此类的函数被重复实现了


//可以兼容dll创建者，dll使用者，直接作为普通文件包含在exe程序里面的导出设定--add by lizulin
//dll创建者项目预定义BASIC_API_EXPORT 
//dll使用者项目预定义BASIC_API_IMPORT
//作为普通文件在exe程序中直接包含使用，不需要预定义

#if defined(_WIN32)
    #if defined(BASIC_API_EXPORT)
        #define BASIC_API __declspec(dllexport)
    #elif defined(BASIC_API_IMPORT)
        #define BASIC_API __declspec(dllimport)
    #else
        #define BASIC_API 
    #endif
#else
    #define BASIC_API 
#endif

//作为文件在CoreApp_Dcap_Stand_alone中使用需要inline   //CoreApp_Dcap,CoreApp_Mpu,
//作为动态库在Core_Dcap和Core_Mpu中使用inline 会链接错误
//暂时在CoreApp_Dcap_Stand_alone项目中定义宏作为分支，以后有空解决

#if defined(TEMPLATE_INLINE)     
#define INLINE inline 
#else
#define INLINE 
#endif



#include <stdio.h>
static void print_hex(char* buf,unsigned int len) 
{
    for(unsigned int i=0;i<len;i++) 
    {
        printf("%02X ",(unsigned char)buf[i]);
        if(15 == i%16)
            printf("\n");
    }
    printf("\n");
}

//中文字符下可能有问题待修正
inline std::wstring SM_StringToWString(const std::string &str)
{
    std::wstring wstr(str.length(),L' ');
    std::copy(str.begin(), str.end(), wstr.begin());
    return wstr; 
}
inline std::string SM_WStringToString(const std::wstring &wstr)
{
    std::string str(wstr.length(), ' ');
    std::copy(wstr.begin(), wstr.end(), str.begin());
    return str; 
}


//进程结束后会自动断开与共享内存的连接吗？
//进程结束后,共享内存的引用计数会减1.当引用计数为0时,共享内存自动释放.所以结论是会自动断开.
//PS:windows系统是如此,其他系统不清楚. linux好像程序崩溃不会释放共享内存
//自己加引用计数控制释放？ 好像没有必要暂留


class ShareMemoryByMapPrivate;
//基于map的共享内存
class BASIC_API ShareMemoryByMap
{
#pragma pack(push,1)     //设置一个字节对齐 保存对齐状态
    struct ShareMemRef
    {
        volatile	int SumInUse;   //共享内存的引用计数，多一个使用者加一，最后一个使用者释放
    };
#pragma pack(pop)

private:
    ShareMemoryByMap(const ShareMemoryByMap& r); 
    ShareMemoryByMap& operator=(const ShareMemoryByMap& r);
public:  //默认共享内存大小可以设定  如32*1024*1024  sizeof(SHAREMEM)
    INLINE ShareMemoryByMap (unsigned int Size=1024,std::string sKey=("keyName"),bool ClearFirstUse=true);
    INLINE ~ShareMemoryByMap (); 
    INLINE char* getAddress() const //可以直接读写的共享内存地址
   {
        return (char*)pBufShare;
   }
   INLINE unsigned int getSize() const              //已经申请的共享内存内存大小
   {
       return ShareSize-sizeof(ShareMemRef);   //减去引用计数结构大小
   }
    INLINE void Print(unsigned int nsize=0XFFFFFFFF)const;     //如果已经获取，打印内存空间前n个字节,默认打印全部
private:
    unsigned int ShareSize;                 //共享的内存大小  至少大于sizeof(SHAREMEM),作为自身的引用计数

#if UNICODE
    std::wstring sMemName;                //共享内存块文件名
#else
    std::string sMemName;                //共享内存块文件名
#endif

    char* pBufCreator;                        //创建者的读写指针,创建成功可以用这个指针读写数据
    char* pBufUser;                            //使用者读写指针, 获取成功可以用这个指针读写数据
    char* pBufShare;                          //任何进程可以读可以写的指针 
    ShareMemRef* pShareMemSelf;  //多申请一点内存放尾部作为使用者的引用计数
    bool isClearFirstUse;                     //共享内存首次参加者是否清空内存标记
    bool  isCreatOK;                           //创建成功标志
    bool  isGetOK;                              //获取成功标志
    ShareMemoryByMapPrivate* pimpl;
protected:
    //改创建者使用者模式，只需要一个进程中创建一次，在其他多个子进程中可以多获取获取
    INLINE void  CreateNewShareMemory();           //创建新的内存共享区域
    INLINE void  GetExistShareMemory();               //获取已经存在的内存共享区域
    INLINE void  UnmapFromCreator();                  //创建者取消本进程地址空间的映射
    INLINE void  UnmapFromUser();                       //使用者取消本进程地址空间的映射
    //再次封装，不分创建和使用，任何子进程，先获取看有没有存在的共享内存,没有就创建
    INLINE void GetShareMemory();
    INLINE void Close();                                         //取消本进程的映射，根据是否是最后一个使用者释放内存
    INLINE void Release();
};



class ShareMemoryByMapPrivate;


#if defined(_WIN32)

typedef void* HANDLE;

class ShareMemoryByMapPrivate
{
public:
    HANDLE HandleCreator;            //创建返回句柄，用此句柄释放共享内存，创建者才可以？
    HANDLE HandleUser;                //使用者句柄
    ShareMemoryByMapPrivate()
    {
        HandleCreator=NULL;
        HandleUser=NULL;
    }
};
#else //Linux
class ShareMemoryByMapPrivate
{
public:
    int HandleCreator;
    int HandleUser;  
    ShareMemoryByMapPrivate()
    {
        HandleCreator=-1;
        HandleUser=-1;  
    }
};
#endif
//多申请sizeof(SHAREMEM)作为自身引用计数
ShareMemoryByMap::ShareMemoryByMap(unsigned int Size,std::string sKey,bool ClearFirstUse) :ShareSize(Size+sizeof(ShareMemRef)),isClearFirstUse(ClearFirstUse)  //sMemName(sKey),
{
    pimpl=new ShareMemoryByMapPrivate;

#ifdef UNICODE
    sMemName=SM_StringToWString(sKey);
#else
    sMemName=sKey;
#endif

    pBufCreator=NULL;
    pBufUser=NULL;                      //使用者读写指针
    pBufShare=NULL;
    isCreatOK=false;
    isGetOK=false;

    pShareMemSelf=NULL;
    GetShareMemory();
}

ShareMemoryByMap::~ShareMemoryByMap()
{
    Close();  //取消本进程的映射，根据是否是最后一个使用者释放共享内存
    delete pimpl;
}
//再次封装，不分创建和使用，任何子进程，先获取看有没有存在的共享内存,没有就创建
void ShareMemoryByMap::GetShareMemory()
{
    GetExistShareMemory() ;    
    if(isGetOK==true)
    {
        pBufShare=pBufUser;
        pShareMemSelf=(ShareMemRef*)(pBufShare+ShareSize);
        pShareMemSelf->SumInUse++;       //使用者加一，保存在共享内存
    }
    else
    {
        CreateNewShareMemory();
        if(isCreatOK==true)
        {
            pBufShare=pBufCreator;
            //创建者初始化内存为0  根据需要决定
            if (isClearFirstUse)
            {
                memset(pBufShare,0,ShareSize);
            }
            pShareMemSelf=(ShareMemRef*)(pBufShare+ShareSize);
            pShareMemSelf->SumInUse=0;        //new 使用者初始化为0
            pShareMemSelf->SumInUse++;       //使用者加一，保存在共享内存
        }
        else
        {
            pBufShare=NULL;
            pShareMemSelf=NULL;
        }
    }
    printf("MapShareMemory::GetShareMemory() Users Num:%d\n",pShareMemSelf->SumInUse);
}

void ShareMemoryByMap::Close()                 //取消本进程的映射，根据是否是最后一个使用者释放内存
{
    //if(NULL!=pShareMemSelf)
    //{
    //    pShareMemSelf->SumInUse--;             //使用者-1，保存在共享内存
    //    if (pShareMemSelf->SumInUse<=0)    //最后使用者删除这片共享内存,好像没有必要，内核已经用引用计数管理了
    //    {
    //        Release();
    //    }
    //    printf("MapShareMemory::ReleaseMemory() Users Num:%d\n",pShareMemSelf->SumInUse);

    //    pBufShare==NULL;
    //    pShareMemSelf=NULL;  //？
    //}
    UnmapFromCreator();
    UnmapFromUser();
    Release();
}

void ShareMemoryByMap::Print(unsigned int nsize) const    //如果已经获取，打印内存空间前n个字节
{   
    if(NULL==pBufShare)
    {
        return;
    }
    if(nsize>ShareSize)
    {
        nsize=ShareSize;
    }
    print_hex(pBufShare,nsize);
}


#if defined(_WIN32)

#include <Windows.h>
void  ShareMemoryByMap::CreateNewShareMemory()
{
#ifdef UNICODE
    std::string sMprintName=SM_WStringToString(sMemName);
#else
    std::string sMprintName=sMemName;
#endif

    printf("MapShareMemory::CreatorNewShareMemory(): Size:%d Byte;Name:%s\n",ShareSize,sMprintName.c_str());
    pBufCreator = NULL;
    //创建一个有名的共享内存
    pimpl->HandleCreator = CreateFileMapping(
        INVALID_HANDLE_VALUE,     //=0xFFFFFFFF表示创建一个进程间共享的对象
        NULL,
        PAGE_READWRITE,                //读写共享
        0,
        ShareSize,                            //共享区间大小
        this->sMemName.c_str());//映射文件名，即共享内存的名称
    if (NULL == pimpl->HandleCreator)
    {
        if (ERROR_ALREADY_EXISTS == GetLastError())
        {
            printf("Already exists!\n");
        }
        else if(ERROR_INVALID_HANDLE==GetLastError())
        {
            printf("发现的命名内存空间和现有的内存映射, 互斥量, 信号量, 临界区同名\n");
        }
        else
        {
            printf("Create Sheared Memory failed\n");
        }
        isCreatOK=false;
        return;
    }

    //映射到本进程的地址空间  FILE_MAP_ALL_ACCESS FILE_MAP_READ  FILE_MAP_WRITE
    pBufCreator = (char*)MapViewOfFile(pimpl->HandleCreator,FILE_MAP_ALL_ACCESS, 0, 0,ShareSize);
    if (NULL==pBufCreator)
    {
        printf("MapShareMemory::CreatorNewShareMemory() MapViewOfFile() failed\n");
        isCreatOK=false;
        return;
    }
    isCreatOK=true;               //创建成功
}


void  ShareMemoryByMap::GetExistShareMemory()                              //获取已经存在的内存共享区域
{
#ifdef UNICODE
    std::string sMprintName=SM_WStringToString(sMemName);
#else
    std::string sMprintName=sMemName;
#endif

    printf("MapShareMemory::UserGetShareMemory() Size=%d Byte;Name:%s\n",ShareSize,sMprintName.c_str());

    //映射到本进程的地址空间 
    pimpl->HandleUser = OpenFileMapping(FILE_MAP_ALL_ACCESS,false,this->sMemName.c_str());
    if (NULL == pimpl->HandleUser)
    {
        printf("OpenFileMapping  failed GetLastError()=%d\n",GetLastError());
        isGetOK=false;
        return;
    }
    //读写权限FILE_MAP_ALL_ACCESS FILE_MAP_READ  FILE_MAP_WRITE
    pBufUser = (char*)MapViewOfFile(pimpl->HandleUser,FILE_MAP_ALL_ACCESS, 0, 0,ShareSize);
    if (NULL == pBufUser)
    {
        printf("MapViewOfFile  failed\n");
        isGetOK=false;
        return;
    }
    isGetOK=true;
    //CloseHandle(pimpl->HandleUser);
}

void  ShareMemoryByMap::UnmapFromCreator()           //创建者取消本进程地址空间的映射
{
    //本对象是创建者
    if(pBufCreator!=NULL)
    {
        UnmapViewOfFile(pBufCreator); 
        pBufCreator=NULL;
    }
    //pBufCreator=NULL;  //取消映射后不可以再操作
}

void  ShareMemoryByMap::UnmapFromUser()              //使用者取消本进程地址空间的映射
{
    //本对象不是创建者
    if(pBufUser!=NULL)
    {
        UnmapViewOfFile(pBufUser); 
        pBufUser=NULL; 
    }
    //pBufUser=NULL;   //取消映射后不可以再操作
}

void ShareMemoryByMap::Release()
{
    //加上反而有问题，待确认
    //if (pimpl->HandleCreator!=NULL)
    //{
    //    CloseHandle(pimpl->HandleCreator);
    //    pimpl->HandleCreator=NULL;
    //}
    //if (pimpl->HandleUser!=NULL)
    //{
    //    CloseHandle(pimpl->HandleUser);
    //    pimpl->HandleUser=NULL;
    //}
}

#else   //LINUX 

void  ShareMemoryByMap::GetExistShareMemory() //获取已经存在的内存共享区域
{
    key_t mem_key;
    // int shmid;  
    void* segptr;  
    mem_key=ftok(sMemName.c_str(),1);
    if ((key_t)(-1)==mem_key) 
    {
      //  printf("Failed to generate shared memory access key, ERRNO=%d\n", errno);
        isGetOK=false;
        return;
    }

    if((pimpl->HandleUser=shmget(mem_key,ShareSize, 0))==-1)  
    {  
        isGetOK=false;
        return;
    }   
    if((segptr=shmat(pimpl->HandleUser, 0, 0))==(void *)-1)   
    {  
        isGetOK=false;
        return;
    }
    pBufUser=(char*)segptr;
    isGetOK=true;
    return;
}

void  ShareMemoryByMap::CreateNewShareMemory()  //创建新的共享内存
{
    key_t mem_key;
   // int shmid;  
    void* segptr;  
    mem_key=ftok(sMemName.c_str(),1);
    if ((key_t)(-1)==mem_key) 
    {
        //  printf("Failed to generate shared memory access key, ERRNO=%d\n", errno);
        isCreatOK=false;
        return;
    }

    if((pimpl->HandleCreator=shmget(mem_key,ShareSize,IPC_CREAT|IPC_EXCL|0666))==-1)  
    {  
        isCreatOK=false;
        return;
    }

    if((segptr=shmat(pimpl->HandleCreator, 0, 0))==(void *)-1)   
    {  
        isCreatOK=false;
        return;
    }  
    pBufCreator=(char*)segptr;
    isCreatOK=true;
    return;
}

void  ShareMemoryByMap::UnmapFromCreator()           //创建者取消本进程地址空间的映射
{
    //本对象是创建者
    if(pBufCreator!=NULL)
    {
        shmdt(pBufCreator); //禁止本进程访问此片共享内存
        pBufCreator = NULL;
    }
}

void  ShareMemoryByMap::UnmapFromUser()              //使用者取消本进程地址空间的映射
{
    //本对象是创建者
    if(pBufUser!=NULL)
    {
        shmdt(pBufUser); //禁止本进程访问此片共享内存
        pBufUser = NULL;
    }
}

void ShareMemoryByMap::Release()
{
    //两个进程都删除会不会有问题？
    //if (Usershmid!=-1)
    //{
    //    shmctl(Usershmid,IPC_RMID,0);
    //}
    //else if (Creatorshmid!=-1)
    //{
    //    shmctl(Creatorshmid,IPC_RMID,0);
    //}
}
#endif










//（2）数据接收
//在数据接收进程中，首先调用OpenFileMapping()函数打开一个命名的内存映射文件对象，
//得到相应内存起始位置指针lhShareMemory。如果打开成功，则调用MapViewOfFile()
//函数映射对象的一个视图，得到指向映射到内存的第一个字节的指针lpcBuffer并通过该
//指针读写共享的内存区域。最后调用UnmapViewOfFile()函数来解除视图映射，传入参数
//为lpcBuffer，调用CloseHandle()函数来关闭内存映射文件，传入参数为lhShareMemory，
//具体代码如下：








#if 0
class PipeShameMemoryPrivate;
class BASIC_API PipeShameMemory
{
public:
    PipeShameMemory ();
    ~PipeShameMemory () ;

    void OnPipeCreate();
    void OnSend();
    void Onrecieve();
    void OnPipeConnect();
    void  Onrecieve2();
    void OnSend2();
private:
    PipeShameMemoryPrivate* pimpl;
};
#endif
//4．管道方式
//管道的类型有两种：匿名管道和命名管道。匿名管道是不命名的，它最初用于本地系统中父进程与
//它启动的子进程之间的通信。命名管道则高级一些，通过一个名字进行标识，使客户端和服务端
//应用程序可以通过该管道进行通信。Win32命名管道甚至可以在不同系统的进程间使用，这使它
//成为许多客户/服务器应用程序的理想之选。
//现在我们用命名管道实现进程间的通信，具体实现过程如下。
//（1）创建命名管道，具体代码如下



#if 0

class PipeShameMemoryPrivate;
class BASIC_API PipeShameMemory
{
public:
    PipeShameMemory ();
    ~PipeShameMemory () ;

    void OnPipeCreate();
    void OnSend();
    void Onrecieve();
    void OnPipeConnect();
    void  Onrecieve2();
    void OnSend2();
private:
    PipeShameMemoryPrivate* pimpl;
};


class PipeShameMemoryPrivate
{
public:
    HANDLE hPipe;
};
PipeShameMemory::PipeShameMemory ()
{
    pimpl=new PipeShameMemoryPrivate;
}
PipeShameMemory::~PipeShameMemory () 
{
    delete pimpl;
}

void PipeShameMemory::OnPipeCreate()
{
    pimpl->hPipe=CreateNamedPipe(("\\\\.\\pipe\\MyPipe"),
        PIPE_ACCESS_DUPLEX | FILE_FLAG_OVERLAPPED,
        0,1,1024,1024,0,NULL);
    //PIPE_ACCESS_DUPLEX 管道是双向的
    //FILE_FLAG_OVERLAPPED 允许（但不要求）用这个管道进行异步（重叠式）操作
    //nMaxInstances Long，这个管道能够创建的最大实例数量。必须是1到常数PIPE_UNLIMITED_INSTANCES间的一个值。它对于管道的所有实例来说都应是相同的
    //nOutBufferSize Long，建议的输出缓冲区长度；零表示用默认设置
    //nInBufferSize Long，建议的输入缓冲区长度；零表示用默认设置
    //nDefaultTimeOut Long，管道的默认等待超时。对一个管道的所有实例来说都应相同

    if(INVALID_HANDLE_VALUE==pimpl->hPipe)
    {
        // MessageBox("创建命名管道失败！");
        printf("创建命名管道失败!\n");

        pimpl->hPipe=NULL;
        return;
    }
    HANDLE hEvent;
    hEvent=CreateEvent(NULL,TRUE,FALSE,NULL);
    if(!hEvent)
    {
        //  MessageBox("创建事件对象失败！");
        CloseHandle(pimpl->hPipe);
        pimpl->hPipe=NULL;
        return;
    }
    OVERLAPPED ovlap;
    ZeroMemory(&ovlap,sizeof(OVERLAPPED));
    ovlap.hEvent=hEvent;
    if(!ConnectNamedPipe(pimpl->hPipe,&ovlap))
    {
        if(ERROR_IO_PENDING!=GetLastError())
        {
            // MessageBox("等待客户端连接失败！");
            printf("等待客户端连接失败！\n");

            CloseHandle(pimpl->hPipe);
            CloseHandle(hEvent);
            pimpl->hPipe=NULL;
            return;
        }
    }

    if(WAIT_FAILED==WaitForSingleObject(hEvent,INFINITE))
    {
        //MessageBox("等待对象失败！");
        printf("等待对象失败！\n");

        CloseHandle(pimpl->hPipe);
        CloseHandle(hEvent);
        pimpl->hPipe=NULL;
        return;
    }
    CloseHandle(hEvent);
}


//（2）写入数据，对于命名管道的数据写入操作，与上面匿名管道的写入操作也是相同的，代码如下
void PipeShameMemory::OnSend()
{
    // UpdateData(TRUE);
    // char * buf = (char*)(LPCTSTR)m_strsend;
    char  buf[256];
    memset(buf,99,sizeof(buf));

    DWORD dwWrite;
    if(!WriteFile(pimpl->hPipe,buf,100,&dwWrite,NULL))
    {
        //MessageBox("写入数据失败！");
        printf("写入数据失败！\n");
        return;
    }

    //写入的数据
    printf("写入的数据:\n");
    print_hex(buf,sizeof(buf));
}

//（3）读取数据，对于命名管道的数据读取操作，与上面匿名管道的读取操作是一样的，代码如下
void PipeShameMemory::Onrecieve()
{
    char buf[256];
    DWORD dwRead;
    if(!ReadFile(pimpl->hPipe,buf,100,&dwRead,NULL))
    {
        //MessageBox(_T("读取数据失败！"));
        printf("读取数据失败！\n");
        return;
    }

    //读取到的数据
    printf("读取到的数据:\n");
    print_hex(buf,sizeof(buf));

    //m_strrecieve=buf;
    // UpdateData(FALSE);
}


//（4）连接命名管道。客户端在连接服务器端程序创建的命名管道之前，首先应判断一下，
//是否有可以利用的命名管道，这可以通过调用WaitNamedPipe()函数实现，该函数会一直
//等待，直到指定的超时间隔已过，或者指定了命名管道的实例可以用来连接了，也就是说该
//管道的服务器进程有了一个未决的ConnectNamedPipe操作。如果当前命名管道的实例
//可以使用，那么客户端就可以调用CreateFile函数打开这个命名管道，与服务端进程进行
//通信了。客户端的连接命名管道的代码如下
//HANDLE hPipe;
void PipeShameMemory::OnPipeConnect()
{
    if(!WaitNamedPipe(("\\\\.\\pipe\\MyPipe"),NMPWAIT_WAIT_FOREVER))
    {
        // MessageBox(_T("当前没有可利用的命名管道实例！"));
        printf("当前没有可利用的命名管道实例！\n");

        return;
    }
    pimpl->hPipe=CreateFile(("\\\\.\\pipe\\MyPipe"),GENERIC_READ | GENERIC_WRITE,
        0,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(INVALID_HANDLE_VALUE==pimpl->hPipe)
    {
        //   MessageBox(_T("打开命名管道失败！"));
        printf("打开命名管道失败！\n");

        pimpl->hPipe=NULL;
        return;
    }
}
//（5）读取数据。如果客户端成功打开了指定的命名管道，那么就可以进行读取和写入操作了，具体代码如下
void  PipeShameMemory::Onrecieve2()
{
    char buf[256];
    DWORD dwRead;
    if(!ReadFile(pimpl->hPipe,buf,100,&dwRead,NULL))
    {
        // MessageBox(_T("读取数据失败！"));
        printf("读取数据失败！\n");

        return;
    }
    // m_strrecieve=buf;
    //  UpdateData(FALSE);
}

//（6）写入数据。客户端向命名管道写入数据与上面服务器端向命名管道写入数据一样，具体代码如下

void PipeShameMemory::OnSend2()
{
    //UpdateData(TRUE);
    // char * buf = (char*)(LPCTSTR)m_strsend;
    char  buf[256];
    DWORD dwWrite;
    if(!WriteFile(pimpl->hPipe,buf,100,&dwWrite,NULL))
    {
        //MessageBox("写入数据失败！");
        printf("写入数据失败！\n");

        return;
    }
}
#endif






#endif