﻿#include "ThreadSync.h"

//namespace Super  {  
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////


#if 0

//C++11 中没有信号量，如何进行同步或互斥？
//condition_variable+mutex啊，pthread世界一直是那么用的。


//作者：匿名用户
//链接：https://www.zhihu.com/question/31555101/answer/117537944
//来源：知乎
//    著作权归作者所有。商业转载请联系作者获得授权，非商业转载请注明出处。
//
#include <mutex>
#include <condition_variable>

class Semaphore {
public:
    Semaphore (int count_ = 0)
        : count(count_) {}

    inline void notify()
    {
        std::unique_lock<std::mutex> lock(mtx);
        count++;
        cv.notify_one();
    }

    inline void wait()
    {
        std::unique_lock<std::mutex> lock(mtx);

        while(count == 0){
            cv.wait(lock);
        }
        count--;
    }

private:
    std::mutex mtx;
    std::condition_variable cv;
    int count;
};
//这位的回答更加的通用：template <typename Mutex, typename CondVar>
class basic_semaphore {
public:
    using native_handle_type = typename CondVar::native_handle_type;

    explicit basic_semaphore(size_t count = 0);
    basic_semaphore(const basic_semaphore&) = delete;
    basic_semaphore(basic_semaphore&&) = delete;
    basic_semaphore& operator=(const basic_semaphore&) = delete;
    basic_semaphore& operator=(basic_semaphore&&) = delete;

    void notify();
    void wait();
    bool try_wait();
    template<class Rep, class Period>
    bool wait_for(const std::chrono::duration<Rep, Period>& d);
    template<class Clock, class Duration>
    bool wait_until(const std::chrono::time_point<Clock, Duration>& t);

    native_handle_type native_handle();

private:
    Mutex   mMutex;
    CondVar mCv;
    size_t  mCount;
};

using semaphore = basic_semaphore<std::mutex, std::condition_variable>;

template <typename Mutex, typename CondVar>
basic_semaphore<Mutex, CondVar>::basic_semaphore(size_t count)
    : mCount{count}
{}

template <typename Mutex, typename CondVar>
void basic_semaphore<Mutex, CondVar>::notify() {
    std::lock_guard<Mutex> lock{mMutex};
    ++mCount;
    mCv.notify_one();
}

template <typename Mutex, typename CondVar>
void basic_semaphore<Mutex, CondVar>::wait() {
    std::unique_lock<Mutex> lock{mMutex};
    mCv.wait(lock, [&]{ return mCount > 0; });
    --mCount;
}

template <typename Mutex, typename CondVar>
bool basic_semaphore<Mutex, CondVar>::try_wait() {
    std::lock_guard<Mutex> lock{mMutex};

    if (mCount > 0) {
        --mCount;
        return true;
    }

    return false;
}

template <typename Mutex, typename CondVar>
template<class Rep, class Period>
bool basic_semaphore<Mutex, CondVar>::wait_for(const std::chrono::duration<Rep, Period>& d) {
    std::unique_lock<Mutex> lock{mMutex};
    auto finished = mCv.wait_for(lock, d, [&]{ return mCount > 0; });

    if (finished)
        --mCount;

    return finished;
}

template <typename Mutex, typename CondVar>
template<class Clock, class Duration>
bool basic_semaphore<Mutex, CondVar>::wait_until(const std::chrono::time_point<Clock, Duration>& t) {
    std::unique_lock<Mutex> lock{mMutex};
    auto finished = mCv.wait_until(lock, t, [&]{ return mCount > 0; });

    if (finished)
        --mCount;

    return finished;
}

template <typename Mutex, typename CondVar>
typename basic_semaphore<Mutex, CondVar>::native_handle_type basic_semaphore<Mutex, CondVar>::native_handle() {
    return mCv.native_handle();
}
#endif






#if 0


/**
 * semaphore类似于一个信号量类，利用mutex和condition_variable来实现
 */
#include <mutex>
#include <condition_variable>
#include <string>
#include <cassert>
#include <chrono>
#include <iostream>

namespace SEM {
    class Semaphore {
    private:
        int _count;                             //等待线程数量
        std::mutex _mutex;                      //互斥锁
        std::condition_variable _condition;     //条件变量
        std::string _name;                      //信号量名字

    public:
        explicit Semaphore(std::string name, int value = 0) :
                _name(std::move(name)), _count(value) {}

        /**
         * 相当于信号量机制里面的P操作.
         * _count大于0(有资源)时,函数会立即返回,否则会阻塞调用此函数的线程.
         */
        void wait() {
            std::unique_lock<std::mutex> lock(_mutex);
            //std::cout<<_name+":"<<_count<<std::endl;
            if (--_count < 0) { // 资源不够
                _condition.wait(lock); // 阻塞
            }
        }

        /**
         * 相当于信号量机制里面的P操作.
         * _count大于0(有资源)时,函数会立即返回,否则会阻塞调用此函数的线程.
         * 但如果等待时间超过seconds指定的值，会唤醒所有阻塞线程.
         * @param ms 等待时间(ms)
         */
        void wait(int ms) {
            assert(ms > 0);
            std::unique_lock<std::mutex> lock(_mutex);
            //std::cout<<_name+":"<<_count<<std::endl;
            if (--_count < 0) {                            // 资源不够
                std::cv_status status
                        = _condition.wait_for(lock, std::chrono::milliseconds(ms));
                if (status == std::cv_status::timeout)   // 超时
                {
                    std::cout << _name + ":timeout" << std::endl;
                    _count = 0;
                    _condition.notify_all();//唤醒所有阻塞线程
                }
            }
        }

        /**
         * 如果有阻塞的线程,则随机唤醒一个线程，相当于信号量机制里面的V操作.否则
         * 立即返回.
         */
        void signal() {
            std::lock_guard<std::mutex> lock(_mutex);
            if (++_count <= 0) {
                _condition.notify_one();
            }
        }

        /**
         * 如果有线程阻塞,唤醒阻塞的所有线程;否则立即返回.
         */
        void signalAll() {
            std::lock_guard<std::mutex> lock(_mutex);
            while (++_count <= 0) {
                _condition.notify_one();
            }
            _count = 0;
        }

        /**
         * 返回这个信号量的名字
         * @return 名字
         */
        std::string name(){
            return _name;
        }

        /**
         * 重载<<,输出信号量的信息
         * @param out 输出流
         * @param sem 信号量
         * @return 输出流
         */
        friend std::ostream &operator<<(std::ostream &out,Semaphore &sem);
    };

    std::ostream &operator<<(std::ostream &out, Semaphore &sem) {
        out<<"Semaphore:"<<sem._name<<",Waiting threads count:"<<sem._count<<std::endl;
        return out;
    }
};

三、使用

用信号量实现一个简单的生产者消费者模型.

#include <iostream>
#include <mutex>
#include <list>
#include <random>
#include "Semaphore.h"
#include <unistd.h>
#include <thread>

using namespace std;

class Goods{
public:
    explicit Goods(int ii):id(ii){
    }
    int id;
};//产品

SEM::Semaphore *g_sem;

list<Goods> g_goods;//商品货架

mutex g_mutex;

void producer(){
    default_random_engine e(static_cast<unsigned long>(time(0)));
    uniform_int_distribution<unsigned> u(0, 10);
    int i=0;
    while (++i<5) {
        //休眠一段随机时间,代表生产过程
        sleep(u(e));
        //生产
        g_mutex.lock();
        Goods good(u(e));
        g_goods.emplace_back(good);
        cout<<"生产产品:"<<good.id<<endl;
        g_mutex.unlock();
        //唤醒一个阻塞的消费者
        g_sem->signal();
    }
}

void costumer(){
    int i=0;
    while (++i<5) {
        g_sem->wait();//有资源会立即返回,没有资源则会等待
        //消费
        g_mutex.lock();
        Goods good = g_goods.front();
        cout<<"消费产品:"<<good.id<<endl;
        g_goods.pop_front();
        g_mutex.unlock();
    }
}
int main() {
    g_sem = new SEM::Semaphore("sem_name",0);
    thread producer_t(producer);
    thread costumer_t(costumer);
    producer_t.join();
    costumer_t.join();
    delete g_sem;
    return 0;
}
#endif



#if 0

//c++11实现写优先的读写锁
#ifndef __WRITE_FIRST_RW_LOCK_H
#define __WRITE_FIRST_RW_LOCK_H

#include <mutex>
#include <condition_variable>

class WfirstRWLock
{
public:
    WfirstRWLock() = default;
    ~WfirstRWLock() = default;
public:
    void lock_read()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        cond_r.wait(ulk, [=]()->bool {return write_cnt == 0; });
        ++read_cnt;
    }
    void lock_write()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        ++write_cnt;
        cond_w.wait(ulk, [=]()->bool {return read_cnt == 0 && !inwriteflag; });
        inwriteflag = true;
    }
    void release_read()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        if (--read_cnt == 0 && write_cnt > 0)
        {
            cond_w.notify_one();
        }
    }
    void release_write()
    {
        std::unique_lock<std::mutex> ulk(counter_mutex);
        if (--write_cnt == 0)
        {
            cond_r.notify_all();
        }
        else
        {
            cond_w.notify_one();
        }
        inwriteflag = false;
    }

private:
    volatile size_t read_cnt{ 0 };
    volatile size_t write_cnt{ 0 };
    volatile bool inwriteflag{ false };
    std::mutex counter_mutex;
    std::condition_variable cond_w;
    std::condition_variable cond_r;
};

template <typename _RWLockable>
class unique_writeguard
{
public:
    explicit unique_writeguard(_RWLockable &rw_lockable)
        : rw_lockable_(rw_lockable)
    {
        rw_lockable_.lock_write();
    }
    ~unique_writeguard()
    {
        rw_lockable_.release_write();
    }
private:
    unique_writeguard() = delete;
    unique_writeguard(const unique_writeguard&) = delete;
    unique_writeguard& operator=(const unique_writeguard&) = delete;
private:
    _RWLockable &rw_lockable_;
};
template <typename _RWLockable>
class unique_readguard
{
public:
    explicit unique_readguard(_RWLockable &rw_lockable)
        : rw_lockable_(rw_lockable)
    {
        rw_lockable_.lock_read();
    }
    ~unique_readguard()
    {
        rw_lockable_.release_read();
    }
private:
    unique_readguard() = delete;
    unique_readguard(const unique_readguard&) = delete;
    unique_readguard& operator=(const unique_readguard&) = delete;
private:
    _RWLockable &rw_lockable_;
};

#endif
//可以看出用c++11实现读写锁变得非常简洁，在读取量非常大且写入频率很低的时候，通
//过一个简单的写入线程计数可以避免大量的 cond_w.notify_one();减少读取线程因此发生的切换。
//这里需要注意的是对写操作加锁时是先增加写线程计数再判断条件并等待，释放写锁时减少
//写线程计数并判断是否还有写操作等待，如果有只能唤醒一个写等待。

#endif







//读写锁
#if 0

//5线程同步-实现读写锁扩展C++11标准库
//在C++11标准库中实现了线程的重要基本设施，使用这些功能轻松构建复杂的多线程程序，
//但是比起微软或者第三库功能还是不怎么全面，比如读写锁就没有实现，但是可以利用已有的功能，轻松实现一个读写锁。代码如下：

#include <thread>
#include <mutex>
#include <condition_variable>


using namespace std;
class shared_mutex
{
private:
    // 锁
    mutex m_mutex;
    // 条件变量
    condition_variable m_cond;
    // 是否在写
    bool m_is_w = false;
    // 读者数量
    size_t m_read_c = 0;
    // 读条件
    bool read_cond() const
    {
        return false == m_is_w;
    }
    // 写条件
    bool write_cond() const
    {
        return false == m_is_w && 0 == m_read_c;
    }

public:
    void read()
    {
        unique_lock<mutex> lck(m_mutex);
        // 函数可能睡眠
        m_cond.wait(lck, bind(&shared_mutex::read_cond, this));
        m_read_c++;
    }

    void unread()
    {
        unique_lock<mutex> lck(m_mutex);
        m_read_c--;
        m_cond.notify_all();
    }

    void write()
    {
        unique_lock<mutex> lck(m_mutex);
        // 匿名函数如果不传指针,当唤醒的时候变量的值依然是睡眠时候的值，
        // 导致函数不能唤醒成功
        m_cond.wait(lck, bind([](const bool *is_w, const size_t *read_c) -> bool
        {
            return false == *is_w && 0 == *read_c;
        }, &m_is_w, &m_read_c));
        m_is_w = true;
    }

    void unwrite()
    {
        unique_lock<mutex> lck(m_mutex);
        m_is_w = false;
        m_cond.notify_all();
    }
};

class read_lock
{
private:
    shared_mutex *m_sm;
public:
    read_lock(shared_mutex &sm)
    {
        m_sm = &sm;
        m_sm->read();
    }
    ~read_lock()
    {
        m_sm->unread();
    }
};

class write_lock
{
private:
    shared_mutex *m_sm;
public:
    write_lock(shared_mutex &sm)
    {
        m_sm = &sm;
        m_sm->write();
    }
    ~write_lock()
    {
        m_sm->unwrite();
    }
};

// 下面是测试代码
shared_mutex sm;

void read(int id)
{
    read_lock lck(sm);
    printf("%d r \n",id);
    this_thread::sleep_for(chrono::milliseconds(300));
    printf("%d r end \n",id);
}

void write(int id)
{
    write_lock lck(sm);
    printf("%d w \n", id);
    this_thread::sleep_for(chrono::milliseconds(300));
    printf("%d w end \n", id);
}

int test_read_write()
{
    thread t1(read, 1);
    thread t2(write, 2);
    thread t3(write, 3);
    thread t4(read, 4);
    t1.join();
    t2.join();
    t3.join();
    t4.join();
    return 0;
}


// atomic 在硬件的支持下，为多线程提供了基本的原子操作
// mutex 在atomic支持下为多线程提供了更长的原子尺度（为程序员抽象出来临界区）
// condition_variable 在mutex的支持下为多线提供了更多的控制关系（为程序员抽象出来同步）
#endif

