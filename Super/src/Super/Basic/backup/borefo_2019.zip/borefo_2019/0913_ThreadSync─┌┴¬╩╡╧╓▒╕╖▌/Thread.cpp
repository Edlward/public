#include "Thread.h"
//#include <iostream>
#include <stdio.h>
#ifdef _WIN32
    #include <windows.h>
     #include <process.h>
#else
    #include <pthread.h>
    #include <unistd.h>
#endif



void MySleep(unsigned int ms)
{
#ifdef _WIN32
          return ::Sleep(ms);
#else
          ::usleep(ms*1000)
#endif
}

class ThreadPrivate
{
public:
    //MyMutex mutex;
private:
};

Thread::Thread()
    :m_thread(0),
    m_running(false),
    m_ContinueRun(true)
{
     pimpl=new ThreadPrivate;
}    

Thread::~Thread()
{
    if(m_running)
    {
        stopWaitFinish();  //stop()
    }

#ifdef _WIN32
    if(m_thread)
    {
        ::CloseHandle(m_thread);
        m_thread=NULL;
    }
#endif                  
    delete pimpl;
}

ThreadHandle Thread::startThread(void* pFunAddr,void* pPara)
{
#ifdef _WIN32
    unsigned int m_ThreadId;
    typedef unsigned int (__stdcall *pThreadFun)(void*);     //����windows�� �̺߳�������
    pThreadFun pFun=(pThreadFun)pFunAddr;                  //ǿת

    ThreadHandle  m_thread= (HANDLE)_beginthreadex(NULL, 0,pFun,pPara,0, &m_ThreadId);   
    if (m_thread==NULL)
    {
        printf("Thread::startThread() �����߳�ʧ��\n");
    }

#else
    ThreadHandle  m_thread;
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    //pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);  //������ ���򲻿���join
    if(pthread_create(&m_thread, &attr,pFunAddr, this) == 1)    //����
    {
        //perror("Thread:create failed");
        printf("Thread::startThread() �����߳�ʧ��\n");
        //setRunning(false);
        //return false; 
    }
#endif

    return m_thread;
}

void Thread::waitFinish(ThreadHandle m_thread)
{
#ifdef _WIN32  
    //WaitForSingleObject(m_thread, INFINITE);  
    //Thread::sleep(1);
    if (NULL!=m_thread)  
    {  
        //if (isRunning())
        //{
            WaitForSingleObject(m_thread, INFINITE);      //����߳��Ѿ�����������WaitForSingleObject��
            //std::cout<<"Thread::waitFinish() WaitForSingleObject()"<<std::endl;
            //CloseHandle(m_thread);  
        //}
        CloseHandle(m_thread);  
        m_thread = NULL;  
    }  
#else  

    //pthread_join(m_thread, NULL);  
    //if (isRunning())
    {
        pthread_join(m_thread, NULL);  
    }
    m_thread = 0;  
#endif // WIN32
}


bool Thread::start()
{
    if (isRunning())
    {
        printf("Thread::start() �ϴε��߳�δ���������ܿ�ʼ�µ��߳�\n");
        return false;
    }

#ifdef _WIN32
    m_thread = (HANDLE)_beginthreadex(NULL, 0, &ThreadCallFun,this, 0, &m_ThreadId);   
    if (m_thread==NULL)
    {
        printf("Thread::Create() ����ʧ��\n");
        return false; 
    }

#else
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    //pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED); //������ ���򲻿���join
    if(pthread_create(&m_thread, &attr, ThreadCallFun, this) == 1)
    {
        //perror("Thread:create failed");
        printf("Thread::Create() ����ʧ��");
        setRunning(false);
        return false; 
    }
#endif

    setContinueRun(true);
    setRunning(true);   //�߳̿����ɹ���������������״̬����, ThreadCallFun�������ÿ��ܻ���ʱ����waitFinish()ʧ��
    //Thread::sleep(1);//Sleep(20);
    return true; 
}


//�̺߳���
ThreadFunRet_t STDCALL Thread::ThreadCallFun(void* pThis)
{
    //printf("ThreadCallFun()--Begin pThread:%p ",pThis);
    Thread *p = (Thread*)pThis;  //static_cast<lcw_thread*>(arg);//ָ��������ָ��ת��Ϊ�������ָ��

    p->setContinueRun(true);
    p->setRunning(true); 
    p->run();              
    p->setRunning(false); //Run()��������
    p->setContinueRun(false);


#ifdef _WIN32
    _endthreadex(0);
#endif
    return (ThreadFunRet_t)NULL;
}


void Thread::waitFinish()
{
#ifdef _WIN32  
    //Thread::sleep(1);
    if (NULL!=m_thread)  
    {  
        if (isRunning())
        {
            WaitForSingleObject(m_thread, INFINITE);      //����߳��Ѿ�����������WaitForSingleObject?
            //std::cout<<"Thread::waitFinish() WaitForSingleObject()"<<std::endl;
            //CloseHandle(m_thread);  
        }
        CloseHandle(m_thread);  
        m_thread = NULL;  
    }  
#else  

    //pthread_join(m_thread, NULL);  
    if (isRunning())
    {
        pthread_join(m_thread, NULL);  
    }
    m_thread = 0;  
#endif // WIN32
    //std::cout<<"Thread::waitFinish() "<<std::endl;
}

bool Thread::isRunning() const
{
    return m_running;    
}

void Thread::setRunning(bool flag)
{
    m_running = flag;    
}

void Thread::stop()
{
     setContinueRun(false);
}

bool Thread::stop(unsigned int timeDelayInms)
{
    setContinueRun(false);
    while(isRunning()&&timeDelayInms>0)    //unsigned int ��Զ����0��ֻ�ܼ�һ�ƽ�
    {
            Thread::sleep(1);
            timeDelayInms-=1;
    }

    //�����������ǿ��ɱ�߳��˳�
    if (isRunning())
    {
#ifdef _WIN32
        if (m_thread)
        {
                ::TerminateThread(m_thread,0);    //windows��ǿ�ƽ����̵߳ĺ���������ȫ
        }
#else

#endif  
        printf("Thread::stop() ǿ�ƽ����߳�\n");
        m_running=false;     //��������������λ����״̬
        return false;
    }

    printf("Thread::stop() ���������߳�\n");
    m_running=false;
    return true;
}

void Thread::stopWaitFinish()
{
    stop();
    waitFinish();
}

void Thread::sleep(unsigned int ms)
{
#ifdef _WIN32
    return ::Sleep(ms);
#else
    ::usleep(ms*1000)
#endif
}

void Thread::sleep_for(unsigned int ms) 
{
    return sleep(ms);
}

void Thread::yield()
{
#ifdef _WIN32
        Thread::sleep(0);  
#else
    //�ο�zthread
    bool result = false;
#if defined(HAVE_SCHED_YIELD)
    result = sched_yield() == 0;
#endif
    return result;
#endif  
}

bool Thread::setPriority(int NewP)
{
#ifdef _WIN32
    bool result;
    int n;
    switch(NewP) 
    {
    case Low:
        n = THREAD_PRIORITY_BELOW_NORMAL;
        break;
    case High:
        n = THREAD_PRIORITY_ABOVE_NORMAL;
        break;
    case Medium:
    default:
        n = THREAD_PRIORITY_NORMAL;
    }
    result = (::SetThreadPriority(m_thread, n) != THREAD_PRIORITY_ERROR_RETURN);
    return result;
#else
    bool result = true;
    struct sched_param param;
    switch(NewP) 
    {
    case Low:
        param.sched_priority = 0;
        break;
    case High:
        param.sched_priority = 10;
        break;
    case Medium:
    default:
        param.sched_priority = 5;
    }
    result = pthread_setschedparam(m_thread, SCHED_OTHER, &param) == 0;
    return result;
#endif  
}

bool Thread::getPriority(int* p)const
{
#ifdef _WIN32
    bool result = true;
    // Convert to one of the PRIORITY values
    switch(::GetThreadPriority(m_thread)) 
    {
    case THREAD_PRIORITY_ERROR_RETURN:
        result = false;
    case THREAD_PRIORITY_BELOW_NORMAL:
        *p = Low;
        break;
    case THREAD_PRIORITY_ABOVE_NORMAL:
        *p = High;
        break;
    case THREAD_PRIORITY_NORMAL:
    default:
        *p = Medium;
    }
    return result;
#else

    bool result = true;
    struct sched_param param;
    int policy = SCHED_OTHER;
    if(result = (pthread_getschedparam(m_thread, &policy, &param) == 0)) 
    {
        // Convert to one of the PRIORITY values
        if(param.sched_priority < 10)
            *p = Low;
        else if(param.sched_priority == 10)
            *p = Medium;
        else
            *p = High;
    }
    return result;
#endif  
}



#include <string>
class ThreadTest:public Thread
{
public:
    ThreadTest(std::string sName):sName(sName){};
    ~ThreadTest(){};
    virtual void run()
    {
        int Num=5;
        while (getContinueRun()&&Num)     //ͨ���ⲿ����shouldExit()����������Ƿ��˳��߳�
        {
            printf("ThreadTest:: run() %s",sName.c_str());
            Thread::sleep(3000);
            //Num--;
        }
    }
private:
    std::string sName;
};



int Test_Thread()
{
    //Thread* pThread=new ThreadTest(false);
    //pThread->Create();

    Thread* pThread=new ThreadTest("TestA");
    pThread->start();

    Thread* pThread2=new ThreadTest("TestB");
    pThread2->start();

    //Thread::sleep(3000);
    //pThread->stop(500);  //ǿ�ƽ�������

    //�߳̽����Ż����е�wait,���������·����ȴ�����߳̽���
    pThread->waitFinish();
    pThread2->waitFinish();

    printf("ThreadTest::����\n");
    return 0;
}

