﻿ #ifndef THREADSYNC_H_
#define THREADSYNC_H_

#include <stdio.h>
#include <string.h>
#include <memory.h>

#include "global.h"

/*本文件主要实现跨平台的线程同步操作类，(暂时只考虑windows与Linux)包括:
用宏判断若编译器支持c++11，直接使用
互斥量:      mutex, 递归锁等,读写互斥锁 写优先 
信号量:      Semaphore,
条件变量:   Condtion Variable

//跨进程跨平台:(进程之间传递数据，消息)
互斥锁
信号量等
*/


//可以兼容dll创建者，dll使用者，直接作为普通文件包含在exe程序里面的导出设定--add by lizulin
//dll创建者项目预定义BASIC_API_EXPORT 
//dll使用者项目预定义BASIC_API_IMPORT
//作为普通文件在exe程序中直接包含使用，不需要预定义

#if defined(_WIN32)
    #if defined(BASIC_API_EXPORT)
        #define BASIC_API __declspec(dllexport)
    #elif defined(BASIC_API_IMPORT)
        #define BASIC_API __declspec(dllimport)
    #else
        #define BASIC_API 
    #endif
#else
    #define BASIC_API 
#endif



//现在比较常用的平台式Linux平台和windows平台，所以我们应该针对不同的平台引用不同的头文件
//平台相关定义
#if defined(__linux__) || defined(__linux)  
    #define OS_LINUX  
#endif

#if defined(_WIN32) || defined(_WIN64)
    #define OS_WIN
#endif



//不同的平台不同的头文件定义
#ifdef OS_WIN
    #include <windows.h>
#else
    #include <pthread.h>

    #include <unistd.h>
    #include <semaphore.h>
    #include <fcntl.h>
    #include <signal.h>
#endif



#if __cplusplus >= 201103L  
#include <random>
#endif 


//namespace Super  {  

//跨平台的快速锁--windows使用临界区实现不能跨进程  允许加锁线程递归加锁  
class MyMutex
{  
public:  
    MyMutex()
    {
        Init();
    }
    ~MyMutex()  
    {  
        clear();
    }
private:
    void Init()
    {
    #if defined(OS_WIN)  
        InitializeCriticalSection(&m_critical_section );  
    #else
        pthread_mutexattr_t attr;  
        pthread_mutexattr_init( &attr );  
        pthread_mutexattr_settype( &attr, PTHREAD_MUTEX_RECURSIVE );    // 这个互斥锁可递归加锁 因为windows下的临界区可以递归加锁  
        pthread_mutex_init( &m_mutex, &attr );  
    #endif
    }

    void clear()
    {
    #if defined(OS_WIN)  
        DeleteCriticalSection( &m_critical_section );  
    #else // defined(OS_LINUX)  
        pthread_mutex_destroy( &m_mutex );  
    #endif  
    }
public:
    void Reinit()   //为了在特殊用途重新构造，一般情况不需要
    {
        clear();
        Init();
    }
    void Lock()  //加锁
    {  
    #if defined(OS_WIN)  
        EnterCriticalSection( &m_critical_section );  
    #else // defined(OS_LINUX)  
        pthread_mutex_lock( &m_mutex );  
    #endif  
    }  
    bool TryLock()   //非阻塞 枷锁成功返回true 否则返回false  
    {  
    #if defined(OS_WIN)  
        if ( !TryEnterCriticalSection( &m_critical_section ) )  
        {  
            return false;  
        }  
    #else //defined(OS_LINUX)  
        if( pthread_mutex_trylock( &m_mutex ) != 0 )  
        {  
            return false;  
        }  
    #endif  
        return true;  
    }  
    void UnLock()  //解锁  
    {  
    #if defined(OS_WIN)  
        LeaveCriticalSection( &m_critical_section );  
    #else //defined(OS_LINUX)  
        pthread_mutex_unlock( &m_mutex );  
    #endif  
    }  
    //后面封装信号量可能会用到
    #ifdef OS_WIN
        inline CRITICAL_SECTION& getMutex(){return m_critical_section;}
    #else
        inline pthread_mutex_t& getMutex(){return m_mutex;}
    #endif

private:  
#if defined(OS_WIN)  
        CRITICAL_SECTION    m_critical_section;        //临界区  windows临界区默认可递归的
#elif defined(OS_LINUX)  
        pthread_mutex_t     m_mutex;                        //互斥锁  
#endif  
private:  
        MyMutex( const MyMutex& ) {};                   // 禁止拷贝和赋值构造 
        MyMutex& operator = ( const MyMutex& ){ return *this; }; 
};  




//自动加锁mutex
class MyAutoLocker  
{  
public:  
     MyAutoLocker(MyMutex& mutex)   
        : m_mutex(mutex)  
    {  
        m_mutex.Lock();  
    }  
    ~ MyAutoLocker()  
    {  
        m_mutex.UnLock();  
    }
protected:  
    MyMutex& m_mutex;  
};  


// 加锁辅助工具 --模版实现 
template<class MutexType>  
class LockerGuard  
{  
public:  
    LockerGuard(MutexType& locker )   
        : m_locker(locker)  
    {  
        locker.Lock();  
    }  
    ~LockerGuard()  
    {  
        m_locker.UnLock();  
    }  
protected:  
    MutexType& m_locker;  
};  

typedef LockerGuard<MyMutex> AutoLocker;     //智能锁RAII




#if 0
//windows条件变量封装
#include <windows.h>
class ncConditionVariable
{
private:
    CONDITION_VARIABLE _cv;
public:
    ncConditionVariable()
    {
        InitializeConditionVariable(_cv);
    }
    ~ncConditionVariable()
    {
    }

public:
    void lock (CRITICAL_SECTION cs, DWORD dwMilliseconds = INFINITE)
    {
        SleepConditionVariableCS (&_cv, &cs, dwMilliseconds);
    }

    void lock (SRWLOCK srwLock, DWORD dwMilliseconds = INFINITE, ULONG Flags = 0)
    {
        SleepConditionVariableSRW (&_cv, &srwLock, dwMilliseconds, Flags);
    }

    void unlock (bool isAll = false)
    {
        if (isAll) {
            WakeConditionVariable (_cv);
        }
        else {
            WakeAllConditionVariable (_cv);
        }
    }
};
#endif


////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//跨平台信号量

//继续参考QT 
//QSemaphore ( int n = 0 )//建立对象时可以给它n个资源  
//	~QSemaphore ()  
//	void acquire ( int n = 1 )// 这个操作一次减少n个资源，如果现有资源不到n个就会阻塞  
//	int available () const   //返回当前可用的QSemaphore资源个数  
//	void release ( int n = 1 )//这个操作一次增加n个资源  
//	bool tryAcquire ( int n = 1 )//类似于acquire，但是申请不到n个资源时不会阻塞会立即返回  
//	bool tryAcquire ( int n, int timeout ) 


//C++11以上版本用std::mutex 和std::condition_variable (条件变量) 实现信号量

//失败 待续
#if 0//(__cplusplus >= 201103L)   //跨进程 信号量不能用C++11实现 必须用系统API
#include <mutex>
#include <condition_variable>

 
 
#else

//自定义信号量，跨平台，根据传递name是否为空，决定有名信号量还是命名信号量
//命名信号量可用于跨进程之间的同步
class MySemaphore
{
#ifdef OS_WIN
public:
    MySemaphore(unsigned int initCount = 1,unsigned int maxCount=1,const char* Name = NULL)
    {
        handel=NULL;
         //记住构造时候的传参值，在重新初始化的时候使用
        this->initCount=initCount;     
        this->maxCount=maxCount;
        //拷贝文件名到类内
        memset(m_name, 0 ,sizeof(m_name));
        if (Name!=NULL)
        {
            int len = strlen(Name)>(sizeof(m_name)-1)?(sizeof(m_name)-1):strlen(Name);
            strncpy(m_name,Name,len);
        }
        m_name[sizeof(m_name)-1]='\0';
        //std::cout<<"信号量名:"<<m_name<<std::endl;
        Create();
    }
    //DWORD Wait(DWORD timeout = INFINITE)
    bool Wait(DWORD timeout = INFINITE)
    {
        DWORD  ret=WaitForSingleObject (handel, timeout);
        switch (ret)
        {
            case WAIT_OBJECT_0://表示等待的对象（比如线程、互斥体）已的正常执行完成或完成释放。
            break;
            case WAIT_TIMEOUT://表示你等待的对象没完成之前，由 WaitForSingleObject 设置的时间已经超时。
            break;
            case WAIT_FAILED://针对等待对象是互斥体的情况，当互斥体对象虽然没有被占用它的线程释放，
                //但是占用它的线程已提前中止时，WaitForSingleObject 就返回此值。// 函数调用失败，比如传递了一个无效的句柄
                printf("MySemaphore Wait() WAIT_FAILED\n");
            break;
        }
        return  ret==WAIT_OBJECT_0;
    }
    //Signal()或release
    //BOOL Signal(LONG lReleaseCount = 1, LPLONG lpPreviousCount = NULL)
    bool Signal(LONG lReleaseCount = 1, LPLONG lpPreviousCount = NULL)
    {
        BOOL ret=ReleaseSemaphore(handel, lReleaseCount, lpPreviousCount);
        return ret==TRUE;
        //lReleaseCount表示增加资源数(必须>0).若该数会导致增加后资源数大于lMaximumCount,则导致调用失败.
        //lpPreviousCount用来获取函数调用前资源数.
        //若资源增加成功则返回非0,否则返回0.
        //信号量使用完成,调用CloseHandle进行清理(所有内核对象都可以使用CloseHandle清理).
        //若资源数大于0,则信号量处于有信号状态.线程使用指定资源前,调用类似WaitForSingleObject的等待函数.
        //若该函数正常返回,则资源数减1.该线程继续执行.线程使用资源完毕后,调用ReleaseSemaphore增加资源数.
    }
    ~MySemaphore()
    {
        Close();
    }
    void Create()
    {
        Tstring sName=FromCstr(m_name);

        //h = CreateSemaphore(NULL, 0, MAXLONG, NULL);
        handel =  OpenSemaphore(SEMAPHORE_ALL_ACCESS,false,sName.c_str());	
        //HANDLE semaphore = OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, _T("Global\\TestSemaphore"));	
        //如果创建失败，获取现有信号量
        if (handel==NULL)
        {
            handel =  CreateSemaphore(NULL, initCount, maxCount,sName.c_str());
            //std::cout<<"创建新的跨进程信号量"<<std::endl;
        }
        if (handel==NULL)
        {
            printf("跨进程信号量打开失败,程序退出");
            exit(-1);
        }
    }
    void Close()
    {
        if (handel!=NULL)
        {
            CloseHandle(handel);
            handel=NULL;
        }
    }
    void ReInit()   //重新初始化，为了在ringbufer中使用是切换状态的时候复位到原来的信号量，一般情况不需要
    {
        Close();     //关闭之后重新打开
        Create();
    }

    void ReSet()  //复位信号量为初始值
    { 
        bool ret=true;
        unsigned int i;
        //while(ret)
        for(i=0;i<maxCount;i++)
        {
            ret=Wait(1);   //使用完所有资源 Wait(0)也可以
            if (ret==false)
            {
                break;
            }
        }
        for(i=0;i<initCount;i++)
        {
            Signal();     //恢复初始资源
        }
    }

    //定义相同功能的接口Acquire  Release更加直观
    bool Acquire(unsigned int TimesWait)
    {
         return Wait(TimesWait);
    }
    bool Release(unsigned int lReleaseCount=1)
    {
        return Signal(lReleaseCount);
    }
private:
    unsigned int initCount;      //记住构造时候的传参值，在重新初始化的时候使用
    unsigned int maxCount;
    char m_name[128];  //std::string ?
    HANDLE handel;
#else     //待续改linux的
public:
    MySemaphore() : count(0)
    {
        pthread_cond_init(&cond, NULL);
    }
    bool Wait()
    {
        MLock l(cs);
        if(count == 0) 
        {
            pthread_cond_wait(&cond, &cs.getMutex());
        }
        count--;
        return true;
    }
    void Signal()
    {
        MLock l(cs);
        count++;
        pthread_cond_signal(&cond);
    }
    bool Wait(unsigned int msecond)
    {
        MLock l(cs);
        if(count == 0) 
        {
            timeval timev;
            timespec t;
            gettimeofday(&timev, NULL);
            t.tv_sec = timev.tv_sec + (msecond/1000);
            t.tv_nsec = (msecond%1000)*1000*1000;
            int ret = pthread_cond_timedwait(&cond, &cs.getMutex(), &t);
            if(ret != 0) 
            {
                return false;
            }
        }
        count--;
        return true;
    }
private:
    pthread_cond_t cond;
    MMutex cs;
    int count;
#endif
private:
    MySemaphore(const MySemaphore&);
    MySemaphore& operator=(const MySemaphore&);
};
#endif



////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//跨进程互斥锁
/*多进程之间的互斥信号量实现(Linux和windows跨平台)

Mutex分为命名和匿名互斥量，进程间只能使用命名方式。
windows下面的操作函数为：CreateMutex，WaitForSingleObject，ReleaseMutex，CloseHandle
linux下面的操作函数为：sem_open，sem_wait，sem_post，sem_close
(关闭当前进程中的互斥量句柄，内核中仍然存在)，sem_unlink(从内核中移除互斥量)
下面封装了一个跨平台实现多进程互斥操作的类，我自己测试过，可以拿来使用：
*/




//linux下的原来用信号量,改成互斥锁实现。
class MyProcessMutex
{
public:
    //默认创建匿名的互斥
    //跨进程互斥锁
#ifdef OS_WIN
    MyProcessMutex(const char* name)
    {
        memset(m_cMutexName, 0 ,sizeof(m_cMutexName));
        int min = strlen(name)>(sizeof(m_cMutexName)-1)?(sizeof(m_cMutexName)-1):strlen(name);
        if (name!=NULL)
        {
                strncpy(m_cMutexName, name, min);
        }
        m_cMutexName[sizeof(m_cMutexName)-1]='\0';
        Tstring sName=FromCstr(m_cMutexName);
        m_pMutex = OpenMutex(MUTEX_ALL_ACCESS,false,sName.c_str());
        //std::cout<<"互斥锁名:"<<m_cMutexName<<std::endl;
        if (m_pMutex==NULL)
        {
            m_pMutex = CreateMutex(NULL, false,sName.c_str());
            printf("创建跨进程互斥锁\n");
        }
        if(m_pMutex==NULL)
        {
            printf("跨进程互斥锁打开失败\n");
            exit(-1);
        }
    }
    ~MyProcessMutex()
    {
        CloseHandle(m_pMutex);
    }
    bool Lock()
    {
        //互斥锁创建失败
        //if (NULL == m_pMutex)
        //{
        //    printf("Error at: ProcessMutex::Lock() NULL=m_pMutex\n");
        //    return false;
        //}
        DWORD nRet = WaitForSingleObject(m_pMutex, INFINITE);
        if (nRet != WAIT_OBJECT_0)
        {
            printf("Error at: ProcessMutex::Lock()\n");
            return false;
        }
        return true;
    }

    bool UnLock()
    {
        //return true;
        return (ReleaseMutex(m_pMutex)!=0);
    }
#endif

#ifdef OS_LINUX
    MyProcessMutex(const char* name)
    {
        memset(m_cMutexName, 0 ,sizeof(m_cMutexName));
        int min = strlen(name)>(sizeof(m_cMutexName)-1)?(sizeof(m_cMutexName)-1):strlen(name);
        strncpy(m_cMutexName, name, min);
        m_pSem = sem_open(name, O_RDWR | O_CREAT, 0644, 1);
    }

    ~MyProcessMutex()
    {
        int ret = sem_close(m_pSem);
        if (0 != ret)
        {
            printf("sem_close error %d\n", ret);
        }
        sem_unlink(m_cMutexName);
    }

    bool Lock()
    {
        int ret = sem_wait(m_pSem);
        if (ret != 0)
        {
            return false;
        }
        return true;
    }

    bool UnLock()
    {
        int ret = sem_post(m_pSem);
        if (ret != 0)
        {
            return false;
        }
        return true;
    }

#endif

private:
#ifdef OS_WIN
    void* m_pMutex;
#else   //#ifdef OS_LINUX
    sem_t* m_pSem;
#endif
    char m_cMutexName[128];
};


//跨进程自动加锁mutex
class MyAutoProcessLocker  
{  
public:  
    MyAutoProcessLocker(MyProcessMutex& mutex)   
        : m_mutex(mutex)  
    {  
        m_mutex.Lock();  
    }
    ~ MyAutoProcessLocker()  
    {  
        m_mutex.UnLock();  
    }
protected:  
    MyProcessMutex& m_mutex;  
};  

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
#endif




