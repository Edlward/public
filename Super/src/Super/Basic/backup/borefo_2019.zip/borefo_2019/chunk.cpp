#include "chunk.h"

dataStruct _packet;

dataStruct::dataStruct()
{
	_data = NULL;
	length = 0;
	mask8 = 1 << 7;
	p = pBit = 0;
}

dataStruct::dataStruct(void *inputData, int len)
{
	_data = (unsigned char *)inputData;
	length = len;
	mask8 = 1 << 7;
	p = pBit = 0;
}

dataStruct::~dataStruct()
{
}

bool dataStruct::nextByte()
{
	p++;
	if(p == length)
	{
		p = 0;
		return false;
	}
	else
	{
		pBit = 0;
	}
	return true;
}

int dataStruct::get_int(int num)
{
	unsigned int buf = get_uint(num);
	char * chp = (char*)&buf;
	if(num == 16)
		return *((short *)chp);
	else if(num == 24)
		return *((Int24 *)chp);

   return *((Int24 *)chp); //NEW
}

unsigned long long dataStruct::get_uint(int num)
{
	unsigned long long ans = 0;
	if(num >= 8)
	{
		for(int i = 0; i < num; i++)
		{
			if(pBit > 7)
				nextByte();
			ans >>= 1;
			ans |= ((unsigned long long)(_data[p] & mask8) << (num - 8));
			_data[p] <<= 1;
			pBit++;
		}
	}
	else
	{
		for(int i = 0; i < num; i++)
		{
			if(pBit > 7)
				nextByte();
			ans >>= 1;
			ans |= ((_data[p] & mask8) >> (8 - num));
			_data[p] <<= 1;
			pBit++;
		}
	}
	return ans;
}

int dataStruct::get_bit()
{
	int ans = 0;
	if(pBit > 7)
		nextByte();
	ans |= ((_data[p] & mask8) >> 7);
	_data[p] <<= 1;
	pBit++;
	return ans;
}

int dataStruct::get_rle()
{
	int ans = 0;
	int tmp;
	do
	{
		if(pBit > 7)
			nextByte();
		pBit++;
		tmp = (_data[p] & mask8);
		_data[p] <<= 1;
		if(tmp == 0)
			break;		
		ans++;
	}while(1);
	return ans;
}

unsigned long long dataStruct::get_var(int N)
{
	unsigned long long ans;
	int K = get_rle();
	int bitNum = (K + 1) * N;
	if(bitNum > 64)
		bitNum = 64;
	ans = get_uint(bitNum);
	return ans;
}

float dataStruct::get_float()
{
	unsigned int num;
	num = get_uint(32);
	return *((float *)&num);
}

frameChunk::frameChunk()
{
	chunkId = 1;
}

int frameChunk::read()
{
	chunkLength = _packet.get_uint(32);
	majorVersion = _packet.get_uint(8);
	minorVersion = _packet.get_uint(8);
	sampleRate = _packet.get_uint(24);
	frameBlockSize = _packet.get_uint(16);
	bitDepth = _packet.get_var(2);
	if(bitDepth == 0)
		bitDepth = 16;
	else 
		bitDepth = 24;
	isNewState = _packet.get_bit();
	_packet.nextByte();  // �߽����

	int subChunkId = _packet.get_uint(16);
	while(1)
	{
		if(subChunkId == 2)
			subChunkId = audio.read(frameBlockSize, bitDepth);
		else if(subChunkId == 3)
			subChunkId = metadata.read(frameBlockSize);
		else
			return subChunkId;
	}

	return 0;  // ��һ��chunkId
}

audioChunk::audioChunk()
{
	chunkId = 2;
}

int audioChunk::read(int frameblocksize, int bitdepth)
{
	pcm.clear();
	silence.clear();
	slc.clear();

	chunkLength = _packet.get_uint(32);
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	while(1)
	{
		if(subChunkId == 4)
		{
			pcmChunk tmpPcmChunk;
			subChunkId = tmpPcmChunk.read(frameblocksize, bitdepth);
			pcm.push_back(tmpPcmChunk);
		}
		else if(subChunkId == 5)
		{
			silenceChunk tmpSilenceChunk;
			subChunkId = tmpSilenceChunk.read(frameblocksize, bitdepth);
			silence.push_back(tmpSilenceChunk);
		}
		else if(subChunkId == 6)
		{
			slcChunk tmpSlcChunk;
			subChunkId = tmpSlcChunk.read(frameblocksize, bitdepth);
			slc.push_back(tmpSlcChunk);
		}
		else
			return subChunkId;
	}
	return 0;  // ��һ��chunkId
}

pcmChunk::pcmChunk()
{
	chunkId = 4;
}

int pcmChunk::read(int frameblocksize, int bitdepth)
{
	chunkLength = _packet.get_uint(32);
	waveformId = _packet.get_var(5);
	sample = new Int24[frameblocksize];

	int i;
	/*if(bitdepth == 16)
	{
		for(i = 0; i < frameblocksize; i++)
		{
			sample[i] = _packet.get_int(16);
		}
	}
	else if(bitdepth == 24)
	{
		for(i = 0; i < frameblocksize; i++)
		{
			sample[i] = _packet.get_int(24);
		}
	}*/

	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;  // ��һ��chunkId
}

silenceChunk::silenceChunk()
{
	chunkId = 5;
}

int silenceChunk::read(int frameblocksize, int bitdepth)
{
	chunkLength = _packet.get_uint(32);
	waveformId = _packet.get_var(5);
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

slcChunk::slcChunk()
{
	chunkLength = 6;
}

int slcChunk::read(int frameblocksize, int bitdepth)
{
	chunkLength = _packet.get_uint(32);
	waveformId = _packet.get_var(5);
	L = _packet.get_uint(2);
	sample = new Int24[frameblocksize];

	int i;
	golombRiceData golo;
	if(bitdepth == 16)
	{
		K = _packet.get_uint(4);
		for(i = 0; i < L; i++)
			sample[i] = _packet.get_int(16);
		for(i; i < frameblocksize; i++)
			sample[i] = golo.read(K);
	}
	else if(bitdepth == 24)
	{
		K = _packet.get_uint(5);
		for(i = 0; i < L; i++)
			sample[i] = _packet.get_int(24);
		for(i; i < frameblocksize; i++)
			sample[i] = golo.read(K);
	}
	compute(frameblocksize);
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

void slcChunk::compute(int frameblocksize)
{
	if(L > 0)
	{
		for(int M = L; M >= 1; M--)
		{
			for(int I = M; I <= frameblocksize - 1; I++)
			{
				sample[I] = sample[I] + sample[I - 1];
			}
		}
	}
}

int golombRiceData::read(int K)
{
	sign = _packet.get_bit();
	B = _packet.get_uint(K);
	H = _packet.get_rle();
	return (sign == 1)? ((1 << K) * H + B) : (-1 - ((1 << K) * H + B)); 
}

metadataChunk::metadataChunk()
{
	chunkId = 3;
}

int metadataChunk::read(int frameblocksize)
{
	sfGroup.clear();
	object.clear();
	group.clear();

	chunkLength = _packet.get_uint(32);
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	while(1)
	{
		if(subChunkId == 7)
		{
			sfGroupChunk tmpSfgChunk;
			subChunkId = tmpSfgChunk.read(frameblocksize);
			sfGroup.push_back(tmpSfgChunk);
		}
		else if(subChunkId == 11)
		{
			objectChunk tmpObjChunk;
			subChunkId = tmpObjChunk.read(frameblocksize);
			object.push_back(tmpObjChunk);
		}
		else if(subChunkId == 14)
		{
			groupChunk tmpGroChunk;
			subChunkId = tmpGroChunk.read();
			group.push_back(tmpGroChunk);
		}
		else
			return subChunkId;
	}
	return 0;
}

sfGroupChunk::sfGroupChunk()
{
	chunkId = 7;
}

int sfGroupChunk::read(int frameblocksize)
{
	sga.clear();
	sgr.clear();

	chunkLength = _packet.get_uint(32);
	sfGroupId = _packet.get_var(5);
	isMainSound = _packet.get_bit();
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	while(1)
	{
		if(subChunkId == 8)
			subChunkId = sgd.read(frameblocksize, channelCount);
		else if(subChunkId == 9)
		{
			sfgAlternativeChunk tmpSfgAChunk;
			subChunkId = tmpSfgAChunk.read(frameblocksize);
			sga.push_back(tmpSfgAChunk);
		}
		else if(subChunkId == 10)
		{
			sfgRemapChunk tmpSfrChunk;
			subChunkId = tmpSfrChunk.read(frameblocksize, channelCount);
			sgr.push_back(tmpSfrChunk);
		}
		else
			return subChunkId;
	}
	return 0;
}

sfgDefinitionChunk::sfgDefinitionChunk()
{
	chunkId = 8;
}

int sfgDefinitionChunk::read(int frameblocksize, unsigned long long &channelcount)
{
	channels.clear();

	chunkLength = _packet.get_uint(32);
	channelCount = _packet.get_var(5);
	channelcount = channelCount;
	for(int i = 0; i < channelCount; i++)
	{
		channelData tmpCnData;
		tmpCnData.read();
		channels.push_back(tmpCnData);
	}
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

int channelData::read()
{
	channelId = _packet.get_var(5);
	routingDestination = _packet.get_var(6);
	waveformId = _packet.get_var(5);
	return 0;
}

int useCaseData::read()
{
	constraints.clear();

	constraintCount = _packet.get_var(2);
	for(int i = 0; i < constraintCount; i++)
	{
		int tmpConstraint = _packet.get_var(4);
		constraints.push_back(tmpConstraint);
	}
	tieBreaker = _packet.get_var(2);
	return 0;
}

sfgAlternativeChunk::sfgAlternativeChunk()
{
	chunkId = 9;
}

int sfgAlternativeChunk::read(int frameblocksize)
{
	channels.clear();

	chunkLength = _packet.get_uint(32);
	useCase.read();
	channelCount = _packet.get_var(5);
	for(int i = 0; i < channelCount; i++)
	{
		channelData tmpCnData;
		tmpCnData.read();
		channels.push_back(tmpCnData);
	}
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

sfgRemapChunk::sfgRemapChunk()
{
	chunkId = 10;
}

int sfgRemapChunk::read(int frameblocksize, unsigned long long channelcount)
{
	routingDestion.clear();
	subframes.clear();

	chunkLength = _packet.get_uint(32);
	useCase.read();
	routingDesCount = _packet.get_var(6);
	for(int i = 0; i < routingDesCount; i++)
	{
		unsigned long long tmpRoutingDes;
		tmpRoutingDes = _packet.get_var(6);
		routingDestion.push_back(tmpRoutingDes);
	}
	subframeBlockSize = _packet.get_uint(16);
	for(int i = 0; i < frameblocksize / subframeBlockSize; i++)
	{
		sfgrsData preSfgrs;
		if(i == 0)
			preSfgrs.set_default(channelcount, routingDesCount);
		else
			preSfgrs = subframes[i - 1];
		sfgrsData tmpSfgrs;
		tmpSfgrs.read(channelcount, routingDesCount, preSfgrs);
		
		subframes.push_back(tmpSfgrs);
	}
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}


void sfgrsData::set_default(unsigned long long channelcount, unsigned long long routingdescount)
{
	gainCoefficient.clear();
	for(int i = 0; i < channelcount * routingdescount; i++)
	{
		gainCoefficient.push_back(0);
	}
}

int sfgrsData::read(unsigned long long channelcount, unsigned long long routingdescount, const sfgrsData preSfgrs)
{
	gainCoefficient.clear();

	int skipSubframe = _packet.get_bit();
	if(skipSubframe == 1)
	{
		*this = preSfgrs;
		return 0;
	}
	unsigned long long up = channelcount * routingdescount;
	for(int i = 0; i < up; i++)
	{
		int skipValue = _packet.get_bit();
		if(skipValue == 0)
		{
			gainCoefficient.push_back(_packet.get_float());
		}
		else
		{
			float tmp = preSfgrs.gainCoefficient[i];
			gainCoefficient.push_back(tmp);
		}
	}
	return 0;
}

objectChunk::objectChunk()
{
	chunkId = 11;
}

int objectChunk::read(int frameblocksize)
{
	objAlt.clear();

	chunkLength = _packet.get_uint(32);
	objectId = _packet.get_var(5);

	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	while(1)
	{
		if(subChunkId == 12)
			subChunkId = objDef.read(frameblocksize);
		if(subChunkId == 13)
		{
			objAltChunk tmpObjAltChunk;
			subChunkId = tmpObjAltChunk.read(frameblocksize);
			objAlt.push_back(tmpObjAltChunk);
		}
		else
			return subChunkId;
	}
	return 0;
}

objDefChunk::objDefChunk()
{
	chunkId = 12;
}

int objDefChunk::read(int frameblocksize)
{
	subframes.clear();

	chunkLength = _packet.get_uint(32);
	isActive = _packet.get_bit();
	isAllocentric = _packet.get_bit();
	if(isActive)
		waveformId = _packet.get_var(5);
	subframeBlockSize = _packet.get_uint(16);

	for(int i = 0; i < frameblocksize / subframeBlockSize; i++)
	{
		objSubframeData preObjSub;
		if(i != 0)
			preObjSub = subframes[i - 1];
		else
			preObjSub.set_default();
		
		objSubframeData tmpObjSub;
		tmpObjSub.read(preObjSub);
		subframes.push_back(tmpObjSub);
	}
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

objAltChunk::objAltChunk()
{
	chunkId = 13;
}

int objAltChunk::read(int frameblocksize)
{
	subframes.clear();

	chunkLength = _packet.get_uint(32);
	useCase.read();
	isActive = _packet.get_bit();
	isAllocentric = _packet.get_bit();
	if(isActive)
		waveformId = _packet.get_var(5);
	subframeBlockSize = _packet.get_uint(16);

	for(int i = 0; i < frameblocksize / subframeBlockSize; i++)
	{
		objSubframeData preObjSub;  // ʹ�ù��캯�������һ��֡Ĭ�ϵĲ���
		if(i == 0)
			preObjSub.set_default();
		else
			preObjSub = subframes[i - 1];
		
		objSubframeData tmpObjSub;
		tmpObjSub.read(preObjSub);
		subframes.push_back(tmpObjSub);
	}
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

void objSubframeData::set_default()
{
	skipSubframe = 0;
	skipPositionX = 0;
	positionX = 0;
	skipPositionY = 0;
	positionY = -1;
	skipPositionZ = 0;
	positionZ = 0;
	skipExtent = 0;
	extent = 0;
	skipGain = 0;
	gain = 1;
	skipCoherence = 0;
	coherence = 1;
	skipSnap = 0;
	snap = 0;
	skipAllZones = 0;
	for(int i = 0; i < 19; i++)
		zoneGain[i] = 1;
}

int objSubframeData::read(const objSubframeData preObjSub)
{
	skipSubframe = _packet.get_bit();
	if(skipSubframe == 1)
	{
		*this = preObjSub;
		return 0;
	}
	skipPositionX = _packet.get_bit();
	if(skipPositionX == 1)
		positionX = preObjSub.positionX;
	else
		positionX = _packet.get_float();

	skipPositionY = _packet.get_bit();
	if(skipPositionY == 1)
		positionY = preObjSub.positionY;
	else
		positionY = _packet.get_float();

	skipPositionZ = _packet.get_bit();
	if(skipPositionZ == 1)
		positionZ = preObjSub.positionZ;
	else
		positionZ = _packet.get_float();
	
	skipExtent = _packet.get_bit();
	if(skipExtent == 1)
		extent = preObjSub.extent;
	else
		extent = _packet.get_float();

	skipGain = _packet.get_bit();
	if(skipGain == 1)
		gain = preObjSub.gain;
	else
		gain = _packet.get_float();

	skipCoherence = _packet.get_bit();
	if(skipCoherence == 1)
		coherence = preObjSub.coherence;
	else
		coherence = _packet.get_float();

	skipSnap = _packet.get_bit();
	if(skipSnap == 1)
		snap = preObjSub.snap;
	else
		snap = _packet.get_float();

	skipAllZones = _packet.get_bit();
	if(skipAllZones == 1)
	{
		for(int i = 0; i < 19; i++)
			zoneGain[i] = preObjSub.zoneGain[i];
	}
	else
	{
		for(int i = 0; i < 19; i++)
		{
			bool skipValue = _packet.get_bit();
			if(skipValue == 1)
				zoneGain[i] = preObjSub.zoneGain[i];
			else
				zoneGain[i] = _packet.get_float();
		}
	}
	return 0;
}

groupChunk::groupChunk()
{
	chunkId = 14;
}

int groupChunk::read()
{
	channelId.clear();
	objId.clear();

	chunkLength = _packet.get_uint(32);
	channelCount = _packet.get_var(4);
	for(int i = 0; i < channelCount; i++)
	{
		unsigned long long tmpChannelId = _packet.get_var(5);
		channelId.push_back(tmpChannelId);
	}
	objCount = _packet.get_var(4);
	for(int i = 0; i < objCount; i++)
	{
		unsigned long long tmpObjId = _packet.get_var(5);
		objId.push_back(tmpObjId);
	}
	_packet.nextByte();
	int subChunkId = _packet.get_uint(16);
	return subChunkId;
}

ObjMetaData::ObjMetaData()
{
	timecode = 0;

	positionX = 0;  // x
	positionY = 0;  // y
	positionZ = 0;  // z
	extent = 0;
	gain = 0;
	coherence = 0;
	snap = 0;
	for(int i = 0; i < 19; i++)
		zoneGain[i] = 0;
}