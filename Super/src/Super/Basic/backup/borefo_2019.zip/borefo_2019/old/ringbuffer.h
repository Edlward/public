﻿#ifndef RINGBUFFER_H_
#define RINGBUFFER_H_
//#include "ringbuffer.h"   //环形缓冲区

/*ringbuffer类模板  20150812  王领
定义windows环境下的环形缓冲区,适用于多个生产者，多个消费者，多个缓冲区的情况。
当缓冲区为满时，写入函数(push())会阻塞并进入等待队列。
当缓冲区为空时，读取函数(get( ))会阻塞并进入等待队列。
当出现饿死的线程时，使用TerminateThread(handle, -1) 结束该线程，并执行clear()函数。
为了减少数据复制的开销，本缓冲区内存储的是指向数据的指针。
在正常使用时，存储指针或者直接存储数据无区别。但是当调用clear函数或者析构函数时，
需要额外对指针进行释放操作。
*/

//refactor  by lizulin 李祖林 2017重构
//重构改封装跨平台的信号量，互斥量等
#include <iostream>
#include "ThreadSync.h"
#include "ThreadSync.cpp"   //同时包含实现文件才能例化模板,否则所有类必须在.h文件实现

//using namespace Super;



//改通过命名信号量，实现跨进程的ringbufer，一个进程里面push，另一个进程里面get，
//通过共享内存实现数据交互


//#include <windows.h>
//#include <process.h>
//#include <iostream>
//using namespace std;

template <class T>
class ringbuffer
{
private:
	T *pData;                                          // 存放数据的指针
	unsigned int BufferSize;                    // 缓冲区大小
	unsigned int WriteIndex;                   // 当前写入位置
	unsigned int ReadIndex;                   // 当前读取位置
	int count;									        // A count for judge buffer empty or not
	//HANDLE semaphoreBufferEmpty;    // 缓冲区有空间的信号量
	//HANDLE semaphoreBufferFull;        // 缓冲区有货物的信号量
	//CRITICAL_SECTION lock;                 // 临界区锁
	MySemaphore mySemaphoreBufferEmpty;
	MySemaphore mySemaphoreBufferFull;
	MyMutex m_mutex;                         //一般互斥互斥锁效率高，windows基于临界区
	//MyProcessMutex ProcessMutex;    //跨进程使用进程间互斥锁，当本类作为跨进程使用时候
public:
	ringbuffer(const unsigned int bufferSize = 128);
	//ringbuffer(const int bufferSize = 128,const char* name=NULL);
	~ringbuffer();
	// 往缓冲区读写数据,否则当flag为true，则无限等待，false则默认时间等待
	bool push(const T& cargo, bool flag = true);      //为了效率用引用
	//T get(bool flag = true);                                     //用返回NULL表明取数据失败不科学，如果是整数缓冲区null为0是有意义的, refactor by lizulin
	//改如下
	bool get(T& cargo,bool flag = true);      

	//往缓冲区读写数据 以timeout作为延时,time=0XFFFFFFFF则无限等待
	bool push(const T& cargo,unsigned int timeout);      //不能设定默认参数，否则调用不明确
	bool get(T& cargo,unsigned int timeout);     

    unsigned int getTotalSize(){return BufferSize;}        // 返回总缓冲区大小，初始化时候决定
    unsigned int getWritePos(){return WriteIndex;}      // 获取写入位置
    unsigned int getReadPos(){return ReadIndex;}       // 获取读取位置
	bool IsFull()                                                           // 改缓冲区是否满标记 lizulin
    {
        if(count >=BufferSize){ return true; }
        return false;
    }
    unsigned int getSize(){return count;}                               // 返回缓冲区货物剩余个数 等于写入个数减去读取个数
	bool clear(bool flag = true);                        // 清空缓冲区--flag为true表明存放的是new出来的指针,需要释放
};


template <class T>
//ringbuffer<T>::ringbuffer(const int bufferSize,const char* name) : // 构造函数
//	mySemaphoreBufferEmpty(bufferSize,bufferSize,name)
//	,mySemaphoreBufferFull(0,bufferSize,name)
ringbuffer<T>::ringbuffer(const unsigned int bufferSize): // 构造函数
	mySemaphoreBufferEmpty(bufferSize,bufferSize)
	,mySemaphoreBufferFull(0,bufferSize)
{
	BufferSize = bufferSize;
	//if(bufferSize <= 0)
	//{
	//	std::cout<<"Can not creat a buffer without storage!\nSo we creat a buffer with 128 storages!"<<std::endl;
	//	bsize = 128;
	//}

	//semaphoreBufferEmpty = CreateSemaphore(NULL, bsize, bsize, NULL);    //初始赋予的信号值  允许的最大的信号值
	//semaphoreBufferFull = CreateSemaphore(NULL, 0, bsize, NULL);
	//InitializeCriticalSection(&lock);

	WriteIndex = 0;
	ReadIndex = 0;
	count = 0;
	//count = BufferSize;
	pData = new T[BufferSize];

/*
	for(int i = 0; i < BufferSize; i++)
	{
		pData[i] = NULL;
	}
*/
	char* pBegin=(char*)pData;
	for(unsigned int i = 0; i < BufferSize*sizeof(T); i++)
	{
		pBegin[i]=0;   //memset   //error 清除出错
	}
}

template <class T>
ringbuffer<T>::~ringbuffer()  // 析构函数
{
	for(unsigned int i = 0; i < BufferSize; i++)  // 若放的不是指针，这句话删去
	{
		//if(data[i] != NULL)
			//delete data[i];
	}
	delete[] pData;

   //CloseHandle(semaphoreBufferEmpty);  
   //CloseHandle(semaphoreBufferFull);  
   //DeleteCriticalSection(&lock); 
	//printf("ringbuffer 析构\n");
}


template <class T>
bool ringbuffer<T>::push(const T& cargo, bool flag)  // 往缓冲区放数据
{
	unsigned int timeout=5;   //默认5ms 
	if(flag == true)
	{
		timeout=0XFFFFFFFF;//INFINITE;      //无限等待
	}
	return push(cargo,timeout);
}

template <class T>
bool ringbuffer<T>::get(T& cargo,bool flag)  // 取出缓冲区数据
{
	unsigned int timeout=5;   //默认5ms 
	if(flag == true)
	{
		timeout=0XFFFFFFFF;//INFINITE;      //无限等待
	}
	return get(cargo,timeout);
}


template <class T>
bool ringbuffer<T>::push(const T& cargo,unsigned int timeout)
{
	//if(WAIT_TIMEOUT == WaitForSingleObject(semaphoreBufferEmpty, 40))
	if(mySemaphoreBufferEmpty.Wait(timeout)==false)
	{
		return false;
	}

	//EnterCriticalSection(&lock);   // 获取临界区锁
	m_mutex.Lock();

	pData[WriteIndex] = cargo;
	//WriteIndex = (WriteIndex + 1) % BufferSize;
    //没有取余除法操作更快
    unsigned int Index=WriteIndex+ 1;
    if (Index>=BufferSize)
    {
        Index=0;
    }
    WriteIndex=Index;

	count++;
	m_mutex.UnLock();
	//LeaveCriticalSection(&lock);  // 释放临界区锁
	mySemaphoreBufferFull.Signal();
	//ReleaseSemaphore(semaphoreBufferFull, 1, NULL);  // 释放有货物的信号量
	return true;
}


template <class T>
bool ringbuffer<T>::get(T& cargo,unsigned int timeout)
{
	//if(WAIT_TIMEOUT == WaitForSingleObject(semaphoreBufferFull, 40))
	if(mySemaphoreBufferFull.Wait(timeout)==false)
	{
		return false; //return NULL;
	}
	//EnterCriticalSection(&lock);   // 获取临界区锁
	m_mutex.Lock();

	//T cargo = pData[ReadIndex];
	cargo = pData[ReadIndex];

	//取完数据 没有必要清除
	//pData[ReadIndex] = NULL;  // 若放的不是指针，这句删去

	//ReadIndex = (ReadIndex + 1) % BufferSize;
    //没有取余除法操作更快
    unsigned int Index=ReadIndex+ 1;
    if (Index>=BufferSize)
    {
        Index=0;
    }
    ReadIndex=Index;

	count--;

	m_mutex.UnLock();
	//LeaveCriticalSection(&lock);  // 释放临界区锁
	//ReleaseSemaphore(semaphoreBufferEmpty, 1, NULL);  // 释放有空的缓冲区的信号量
	mySemaphoreBufferEmpty.Signal();
	//return cargo;
	return true;
}



template <class T>
bool ringbuffer<T>::clear(bool flag = true)  // 清空缓冲区
{
	//return true;
	//ReleaseSemaphore(semaphoreBufferEmpty, 1, NULL);  // 释放有空的缓冲区的信号量
	//_sleep(50);
	//EnterCriticalSection(&lock);   // 获取临界区锁
	m_mutex.Lock();

#if 0
	if(true==flag)  // 若放的是new指针
	{
		for(int i = 0; i < bsize; i++)  // 若放的不是指针，这句话删去
		{
			if(data[i] != NULL)
			{
				delete data[i];
			}
		}
	}
#endif
	 //delete[] data;
	 //CloseHandle(semaphoreBufferEmpty);  
     //CloseHandle(semaphoreBufferFull);  
     //DeleteCriticalSection(&lock); 

	//semaphoreBufferEmpty = CreateSemaphore(NULL, bsize, bsize, NULL);
	//semaphoreBufferFull = CreateSemaphore(NULL, 0, bsize, NULL);

	//InitializeCriticalSection(&lock);
	
	//重新按照初始状态构造信号量
	//mySemaphoreBufferEmpty.ReInit();
    //mySemaphoreBufferFull.ReInit();
 
	//if (IsFull())
	//{
	//	T t;
	//	bool ret=get(t,false);
	//}
	//else
	//{
	//	T t;
	//	bool ret=push(t,false);
	//}


	mySemaphoreBufferEmpty.ReSet();
	mySemaphoreBufferFull.ReSet();

	//读写位置复位
	WriteIndex = 0;
	ReadIndex = 0;
	count = 0;


	m_mutex.UnLock();

#if 0
	data = new T[bsize];
	if(true==flag)  // 若放的是NEW指针
	{
		for(int i = 0; i < bsize; i++)  // 若放的不是指针，这句话删去
		{
			data[i] = NULL;
		}
	}
#endif


	return true;
}

#endif // RINGBUFFER_H_