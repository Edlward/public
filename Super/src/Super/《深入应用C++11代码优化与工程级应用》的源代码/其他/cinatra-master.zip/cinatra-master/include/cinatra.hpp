//
// Created by qicosmos on 2/13/19.
//

#ifndef CINATRA_CINATRA_HPP
#define CINATRA_CINATRA_HPP

#include "cinatra/http_server.hpp"
#include "cinatra/client_factory.hpp"

#endif //CINATRA_CINATRA_HPP
