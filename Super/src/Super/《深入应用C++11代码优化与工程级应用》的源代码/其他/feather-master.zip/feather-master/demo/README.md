所有操作在 demo 目录进行，操作之前需要先安装好 docker。Ubuntu 下安装 docker 参考
```
https://docs.docker.com/install/linux/docker-ce/ubuntu/
```
其它系统参考官网

#### 启动
```
docker-compose up -d
```

#### 访问链接
```
http://localhost:8080
```
首次访问先进入
```
http://localhost:8080/sign_out_page
```
创建一个帐号

#### 停止
```
docker-compose stop
```

#### 清理
```
docker-compose rm
```
